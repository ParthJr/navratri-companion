import { RegisteredUserAccount, getRegisteredAccounts } from '../components/LoginSignupModal';
import { DEFAULT_ADMIN_USERS } from '../super-admin/data/defaultData';
import { AdminUser, AdminRole } from '../super-admin/types';
import { COMPANIONS_DATA } from '../data/companions';
import { Companion } from '../types';

export type AccountRole = 'owner' | 'admin' | 'user' | 'companion';

export interface AuthenticatedAccount {
  id: string;
  userId: string;
  name: string;
  email: string;
  phone: string;
  role: AccountRole;
  adminRole?: AdminRole;
  avatarUrl?: string;
  city?: string;
  status?: string;
  feePaid?: boolean;
  aadhaarImage?: string;
  selfieImage?: string;
}

export interface UnifiedAuthResult {
  success: boolean;
  errorMessage?: string;
  account?: AuthenticatedAccount;
  token?: string;
}

/**
 * Normalizes phone numbers for matching (extracting trailing 10 digits)
 */
const normalizePhone = (phoneStr: string): string => {
  return (phoneStr || '').replace(/[^0-9]/g, '');
};

const matchesPhone = (query: string, storedPhone: string): boolean => {
  const cleanQ = normalizePhone(query);
  const cleanStored = normalizePhone(storedPhone);
  if (!cleanQ || !cleanStored) return false;
  if (cleanQ === cleanStored) return true;
  if (cleanQ.length >= 10 && cleanStored.endsWith(cleanQ)) return true;
  if (cleanStored.length >= 10 && cleanQ.endsWith(cleanStored)) return true;
  return false;
};

/**
 * Universal backend/authentication layer.
 * Validates Master Admin credentials securely via server-side API endpoint (/api/auth/login),
 * and validates registered database users and companions seamlessly.
 */
export const authenticateCredentials = async (
  rawIdentifier: string,
  rawPassword: string
): Promise<UnifiedAuthResult> => {
  const cleanId = (rawIdentifier || '').trim();
  const cleanPass = (rawPassword || '').trim();

  if (!cleanId || !cleanPass) {
    return {
      success: false,
      errorMessage: 'Invalid User ID or Password.',
    };
  }

  const cleanLower = cleanId.toLowerCase();

  // 1. Primary: Server-Side Authentication via Central /api/auth/login
  try {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        identifier: cleanId,
        password: cleanPass,
      }),
    });

    const data = await response.json();

    if (response.ok && data && data.success && data.account) {
      if (data.token && typeof window !== 'undefined') {
        localStorage.setItem('navratri_admin_token', data.token);
      }
      return {
        success: true,
        account: data.account,
        token: data.token,
      };
    }

    // Specific status message from backend (e.g. pending approval, payment rejected, suspended)
    if (response.status === 403 && data.errorMessage) {
      return {
        success: false,
        errorMessage: data.errorMessage,
      };
    }
  } catch (apiError) {
    // Network or server error fallback - continue to check local cache
  }

  // 2. Check Admin Accounts in local configured admin directory (for sub-admins)
  let adminUsersList: AdminUser[] = DEFAULT_ADMIN_USERS;
  try {
    const savedAdmins = localStorage.getItem('navratri_admin_users_config');
    if (savedAdmins) {
      const parsed = JSON.parse(savedAdmins);
      if (Array.isArray(parsed) && parsed.length > 0) {
        adminUsersList = parsed;
      }
    }
  } catch (e) {
    // ignore
  }

  const matchedAdmin = adminUsersList.find((u) => {
    const matchId = (u.adminId || '').trim().toLowerCase() === cleanLower;
    const matchEmail = (u.email || '').trim().toLowerCase() === cleanLower;
    const matchPhone = matchesPhone(cleanId, u.phone);
    return (matchId || matchEmail || matchPhone) && u.password === cleanPass;
  });

  if (matchedAdmin) {
    if (matchedAdmin.status === 'suspended') {
      return {
        success: false,
        errorMessage: 'Account is suspended. Please contact platform owner.',
      };
    }
    const isOwnerRole = matchedAdmin.role === 'super_admin';
    return {
      success: true,
      account: {
        id: matchedAdmin.id,
        userId: matchedAdmin.adminId,
        name: matchedAdmin.name,
        email: matchedAdmin.email,
        phone: matchedAdmin.phone,
        role: isOwnerRole ? 'owner' : 'admin',
        adminRole: matchedAdmin.role,
        status: matchedAdmin.status,
        avatarUrl: matchedAdmin.avatarUrl,
      },
    };
  }

  // 3. Check Registered Accounts (Customers and Companions fallback)
  const registeredAccounts = getRegisteredAccounts();

  const matchedUser = registeredAccounts.find((acc) => {
    const accUserId = (acc.userId || '').trim().toLowerCase();
    const accEmail = (acc.email || '').trim().toLowerCase();
    const matchId = accUserId === cleanLower;
    const matchEmail = accEmail === cleanLower;
    const matchPhone = matchesPhone(cleanId, acc.phone);
    return (matchId || matchEmail || matchPhone) && acc.password === cleanPass;
  });

  if (matchedUser) {
    // Check fee verification status
    if (
      matchedUser.status === 'pending_admin_confirm' ||
      matchedUser.status === 'pending_payment' ||
      matchedUser.feePaid === false
    ) {
      return {
        success: false,
        errorMessage:
          'Your registration is awaiting payment approval. Platform Operations Admin will activate your account shortly.',
      };
    }

    if (matchedUser.status === 'payment_rejected') {
      return {
        success: false,
        errorMessage:
          'Payment verification was rejected by Platform Operations Admin. Please contact support or submit a valid payment.',
      };
    }

    const assignedRole: AccountRole =
      matchedUser.role === 'companion' ? 'companion' : 'user';

    return {
      success: true,
      account: {
        id: matchedUser.userId,
        userId: matchedUser.userId,
        name: matchedUser.name,
        email: matchedUser.email,
        phone: matchedUser.phone,
        role: assignedRole,
        city: matchedUser.city,
        status: matchedUser.status || 'active',
        feePaid: matchedUser.feePaid ?? true,
        aadhaarImage: matchedUser.aadhaarImage,
        selfieImage: matchedUser.selfieImage,
      },
    };
  }

  // 4. Default generic error
  return {
    success: false,
    errorMessage: 'Invalid User ID or Password.',
  };
};

/**
 * Creates isolated session for the authenticated account role.
 */
export const createSessionForAccount = (account: AuthenticatedAccount, token?: string) => {
  if (typeof window === 'undefined') return;

  if (account.role === 'owner' || account.role === 'admin') {
    // Admin Session
    localStorage.setItem('adminSession', 'true');
    localStorage.setItem('navratri_super_admin_auth', 'true');
    localStorage.setItem('navratri_super_admin_user', JSON.stringify(account));
    if (token) {
      localStorage.setItem('navratri_admin_token', token);
    }

    // Clear normal user session to isolate permissions
    localStorage.removeItem('navratri_is_logged_in');
    localStorage.removeItem('navratri_companion_profile');
    localStorage.removeItem('navratri_user_role');
  } else {
    // User or Companion Session
    localStorage.setItem('navratri_is_logged_in', 'true');
    localStorage.setItem('navratri_user_role', account.role);
    localStorage.setItem('navratri_current_user_profile', JSON.stringify(account));

    // CRITICAL SECURITY: Normal user must never receive Admin permissions
    localStorage.removeItem('adminSession');
    localStorage.removeItem('navratri_super_admin_auth');
    localStorage.removeItem('navratri_super_admin_user');
    localStorage.removeItem('navratri_admin_token');
  }
};

/**
 * Completely clears all sessions upon logout
 */
export const clearAllSessions = () => {
  if (typeof window === 'undefined') return;
  localStorage.removeItem('adminSession');
  localStorage.removeItem('navratri_super_admin_auth');
  localStorage.removeItem('navratri_super_admin_user');
  localStorage.removeItem('navratri_admin_token');
  localStorage.removeItem('navratri_is_logged_in');
  localStorage.removeItem('navratri_companion_profile');
  localStorage.removeItem('navratri_user_role');
  localStorage.removeItem('navratri_current_user_profile');
  if (typeof sessionStorage !== 'undefined') {
    sessionStorage.clear();
  }
};

/**
 * Verifies session token with server endpoint
 */
export const verifyAdminSessionOnServer = async (): Promise<boolean> => {
  if (typeof window === 'undefined') return false;
  const token = localStorage.getItem('navratri_admin_token');
  if (!token) {
    const isAuth = localStorage.getItem('adminSession') === 'true';
    return isAuth;
  }

  try {
    const res = await fetch('/api/auth/verify', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ token }),
    });

    if (res.ok) {
      const data = await res.json();
      return data && data.valid === true;
    }
    return false;
  } catch (e) {
    return localStorage.getItem('adminSession') === 'true';
  }
};
