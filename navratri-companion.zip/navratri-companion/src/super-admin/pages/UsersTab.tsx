import React, { useState } from 'react';
import {
  Users,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  AlertCircle,
  ShieldCheck,
  Eye,
  X,
  Phone,
  Mail,
  Calendar,
  CreditCard,
  Ban,
  Check,
  Clock,
  Lock,
  Send,
} from 'lucide-react';
import { useSuperAdmin } from '../context/SuperAdminContext';
import { CustomerUser } from '../types';

export const UsersTab: React.FC = () => {
  const {
    customers,
    updateCustomerStatus,
    verifyCustomerEmail,
    resendCustomerEmailVerification,
    confirmUserPayment,
    rejectUserPayment,
    bookings,
    payments,
    complaints,
  } = useSuperAdmin();

  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | 'customer' | 'companion'>('all');
  const [cityFilter, setCityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [emailFilter, setEmailFilter] = useState<'all' | 'verified' | 'not_verified'>('all');
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerUser | null>(null);
  const [resendNotification, setResendNotification] = useState<string | null>(null);

  const filteredCustomers = customers.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.email.toLowerCase().includes(search.toLowerCase()) ||
      c.id.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.includes(search);

    const userRole = (c.role || 'customer').toLowerCase();
    const matchesRole =
      roleFilter === 'all' ||
      (roleFilter === 'customer' && (userRole === 'customer' || userRole === 'user')) ||
      (roleFilter === 'companion' && userRole === 'companion');

    const matchesCity = cityFilter === 'all' || c.city === cityFilter;
    const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
    const matchesEmail =
      emailFilter === 'all' ||
      (emailFilter === 'verified' && c.emailVerified) ||
      (emailFilter === 'not_verified' && !c.emailVerified);

    return matchesSearch && matchesRole && matchesCity && matchesStatus && matchesEmail;
  });

  const getStatusBadge = (status: CustomerUser['status']) => {
    switch (status) {
      case 'active':
        return 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30';
      case 'suspended':
        return 'bg-amber-500/10 text-amber-400 border border-amber-500/30';
      case 'blocked':
        return 'bg-red-500/10 text-red-400 border border-red-500/30';
      default:
        return 'bg-slate-700 text-slate-300';
    }
  };

  const handleResendEmail = (cust: CustomerUser) => {
    resendCustomerEmailVerification(cust.id);
    setResendNotification(`Verification email sent to ${cust.email}`);
    setTimeout(() => setResendNotification(null), 3500);
  };

  const handleVerifyEmail = (cust: CustomerUser) => {
    verifyCustomerEmail(cust.id);
    if (selectedCustomer && selectedCustomer.id === cust.id) {
      setSelectedCustomer({ ...selectedCustomer, emailVerified: true });
    }
    setResendNotification(`Email marked as Verified for ${cust.name}`);
    setTimeout(() => setResendNotification(null), 3500);
  };

  const customerBookings = selectedCustomer
    ? bookings.filter((b) => b.guestName.toLowerCase() === selectedCustomer.name.toLowerCase())
    : [];

  const customerPayments = selectedCustomer
    ? payments.filter((p) => p.customerName.toLowerCase() === selectedCustomer.name.toLowerCase())
    : [];

  const customerComplaints = selectedCustomer
    ? complaints.filter((c) => c.reporterName.toLowerCase() === selectedCustomer.name.toLowerCase())
    : [];

  return (
    <div className="space-y-6">
      {/* Toast notification banner */}
      {resendNotification && (
        <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{resendNotification}</span>
        </div>
      )}

      {/* Top Filter Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-[#160b24] p-4 rounded-2xl border border-white/10">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search customer by name, email, or phone number..."
            className="w-full bg-[#201033] border border-white/10 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#fd8a42]"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
          {/* Role filter */}
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value as any)}
            className="bg-[#201033] text-xs text-slate-200 border border-white/10 rounded-xl px-3 py-2 focus:outline-none focus:border-[#fd8a42]"
          >
            <option value="all">All Roles</option>
            <option value="customer">Customer (Booker)</option>
            <option value="companion">Companion (Host)</option>
          </select>

          {/* Email verification filter */}
          <select
            value={emailFilter}
            onChange={(e) => setEmailFilter(e.target.value as any)}
            className="bg-[#201033] text-xs text-slate-200 border border-white/10 rounded-xl px-3 py-2 focus:outline-none focus:border-[#fd8a42]"
          >
            <option value="all">All Email Statuses</option>
            <option value="verified">Email: Verified</option>
            <option value="not_verified">Email: Not Verified</option>
          </select>

          <select
            value={cityFilter}
            onChange={(e) => setCityFilter(e.target.value)}
            className="bg-[#201033] text-xs text-slate-200 border border-white/10 rounded-xl px-3 py-2 focus:outline-none focus:border-[#fd8a42]"
          >
            <option value="all">All Cities</option>
            <option value="Ahmedabad">Ahmedabad</option>
            <option value="Gandhinagar">Gandhinagar</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-[#201033] text-xs text-slate-200 border border-white/10 rounded-xl px-3 py-2 focus:outline-none focus:border-[#fd8a42]"
          >
            <option value="all">All Account Statuses</option>
            <option value="active">Active</option>
            <option value="suspended">Suspended</option>
            <option value="blocked">Blocked</option>
          </select>
        </div>
      </div>

      {/* Customer Table */}
      <div className="bg-[#160b24] rounded-2xl border border-white/10 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-[#1f1035] text-slate-400 uppercase text-[10px] tracking-wider font-bold border-b border-white/10">
              <tr>
                <th className="py-3.5 px-4">User</th>
                <th className="py-3.5 px-4">Role</th>
                <th className="py-3.5 px-4">Email &amp; Phone</th>
                <th className="py-3.5 px-4">Payment</th>
                <th className="py-3.5 px-4">City</th>
                <th className="py-3.5 px-4">KYC Status</th>
                <th className="py-3.5 px-4">Registration</th>
                <th className="py-3.5 px-4">Account Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={9} className="text-center py-10 text-slate-500 font-medium">
                    {customers.length === 0 ? 'No registered users in database yet' : 'No users found matching search criteria.'}
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((cust) => (
                  <tr key={cust.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-4 font-semibold text-white whitespace-nowrap">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-[#fd8a42]/20 border border-[#fd8a42]/30 flex items-center justify-center text-xs font-bold text-[#fd8a42]">
                          {cust.name.charAt(0)}
                        </div>
                        <div>
                          <span>{cust.name}</span>
                          <span className="block text-[10px] text-slate-500 font-mono">@{cust.id}</span>
                        </div>
                      </div>
                    </td>

                    {/* Role Badge */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      {cust.role === 'companion' ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-[#fd8a42]/10 text-[#fd8a42] border border-[#fd8a42]/30">
                          Companion
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-blue-500/10 text-blue-300 border border-blue-500/30">
                          Customer
                        </span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="text-slate-200">{cust.email}</div>
                      <div className="text-[10px] text-slate-500">{cust.phone}</div>
                    </td>

                    {/* Payment Status */}
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      {cust.registrationFeePaid || cust.paymentStatus === 'Approved' ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
                          <CheckCircle2 className="w-3 h-3" /> Paid (₹499)
                        </span>
                      ) : cust.paymentStatus === 'Rejected' ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-full border border-rose-500/30">
                          <XCircle className="w-3 h-3" /> Rejected
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30">
                          <Clock className="w-3 h-3" /> Pending
                        </span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 whitespace-nowrap text-slate-300">
                      {cust.city}
                    </td>

                    <td className="py-3.5 px-4 whitespace-nowrap">
                      {cust.idVerified ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
                          <CheckCircle2 className="w-3.5 h-3.5" /> ID Verified
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] text-amber-400">
                          <AlertCircle className="w-3.5 h-3.5" /> Pending Upload
                        </span>
                      )}
                    </td>

                    <td className="py-3.5 px-4 whitespace-nowrap text-slate-400 text-[11px]">
                      {cust.registrationDate}
                    </td>

                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${getStatusBadge(cust.status)}`}>
                        {cust.status}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setSelectedCustomer(cust)}
                          className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white"
                          title="View Profile Details"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        {!cust.emailVerified && (
                          <button
                            onClick={() => handleResendEmail(cust)}
                            className="p-1.5 rounded-lg bg-blue-500/10 hover:bg-blue-500/20 text-blue-400"
                            title="Resend Verification Email"
                          >
                            <Send className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {cust.status === 'active' ? (
                          <button
                            onClick={() => updateCustomerStatus(cust.id, 'suspended')}
                            className="p-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400"
                            title="Suspend Customer"
                          >
                            <Ban className="w-3.5 h-3.5" />
                          </button>
                        ) : (
                          <button
                            onClick={() => updateCustomerStatus(cust.id, 'active')}
                            className="p-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400"
                            title="Activate Customer"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CUSTOMER PROFILE DRAWER / MODAL */}
      {selectedCustomer && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#180e26] border border-white/15 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-150">
            <div className="p-5 bg-[#201333] border-b border-white/10 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold text-[#fd8a42] tracking-wider">
                  Customer Master Record
                </span>
                <h3 className="text-lg font-bold text-white">{selectedCustomer.name}</h3>
              </div>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto custom-scrollbar">
              {/* Personal & Verification Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Account Details</span>
                  <div className="text-xs text-slate-300 space-y-1.5">
                    <p><span className="text-slate-500">Email:</span> {selectedCustomer.email}</p>
                    <p><span className="text-slate-500">Phone:</span> {selectedCustomer.phone}</p>
                    <p><span className="text-slate-500">City:</span> {selectedCustomer.city}</p>
                    <p><span className="text-slate-500">Registered:</span> {selectedCustomer.registrationDate}</p>
                    <p><span className="text-slate-500">Total Spent:</span> ₹{selectedCustomer.totalSpent}</p>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                  <span className="text-[10px] uppercase font-bold text-emerald-400">Verification &amp; Security</span>
                  
                  {/* Registration Fee Payment Status */}
                  <div className="flex items-center justify-between p-2 rounded-xl bg-white/5 text-xs">
                    <div className="flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-purple-400" />
                      <span>Registration Fee Payment:</span>
                    </div>
                    {selectedCustomer.registrationFeePaid || selectedCustomer.paymentStatus === 'Approved' ? (
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Approved &amp; Paid
                      </span>
                    ) : selectedCustomer.paymentStatus === 'Rejected' ? (
                      <span className="text-rose-400 font-bold flex items-center gap-1">
                        <XCircle className="w-3.5 h-3.5" /> Rejected
                      </span>
                    ) : (
                      <span className="text-amber-400 font-bold flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" /> Pending Verification
                      </span>
                    )}
                  </div>

                  {/* Payment Approve / Reject actions */}
                  {(!selectedCustomer.registrationFeePaid || selectedCustomer.paymentStatus === 'Pending Verification') && (
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          confirmUserPayment(selectedCustomer.id);
                          setSelectedCustomer({ ...selectedCustomer, registrationFeePaid: true, status: 'active', paymentStatus: 'Approved' });
                          setResendNotification(`Payment approved! Account @${selectedCustomer.id} activated.`);
                          setTimeout(() => setResendNotification(null), 3500);
                        }}
                        className="flex-1 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1 transition-colors"
                      >
                        <Check className="w-3 h-3" /> Approve Payment
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          rejectUserPayment(selectedCustomer.id, 'Payment verification rejected by admin');
                          setSelectedCustomer({ ...selectedCustomer, registrationFeePaid: false, status: 'suspended', paymentStatus: 'Rejected' });
                          setResendNotification(`Payment rejected for @${selectedCustomer.id}.`);
                          setTimeout(() => setResendNotification(null), 3500);
                        }}
                        className="py-1.5 px-3 bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white rounded-lg text-[11px] font-medium flex items-center gap-1 transition-colors border border-rose-500/30"
                      >
                        <X className="w-3 h-3" /> Reject
                      </button>
                    </div>
                  )}

                  {/* Email verification row */}
                  <div className="flex items-center justify-between p-2 rounded-xl bg-white/5 text-xs">
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-slate-400" />
                      <span>Email Status:</span>
                    </div>
                    {selectedCustomer.emailVerified ? (
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Verified
                      </span>
                    ) : (
                      <span className="text-amber-400 font-bold flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" /> Not Verified
                      </span>
                    )}
                  </div>

                  {/* Resend / Mark email verified controls */}
                  {!selectedCustomer.emailVerified && (
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => handleVerifyEmail(selectedCustomer)}
                        className="flex-1 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1 transition-colors"
                      >
                        <Check className="w-3 h-3" /> Mark Email Verified
                      </button>
                      <button
                        type="button"
                        onClick={() => handleResendEmail(selectedCustomer)}
                        className="py-1.5 px-3 bg-white/10 hover:bg-white/20 text-slate-200 rounded-lg text-[11px] font-medium flex items-center gap-1 transition-colors"
                      >
                        <Send className="w-3 h-3" /> Resend Email
                      </button>
                    </div>
                  )}

                  {/* Identity documents preview */}
                  <div className="pt-1">
                    <p className="text-xs font-semibold text-slate-300 mb-2">Submitted Identity Documents</p>
                    {selectedCustomer.aadhaarImage || selectedCustomer.selfieImage || (selectedCustomer as any).profilePhoto ? (
                      <div className="flex flex-wrap items-center gap-3">
                        {(selectedCustomer as any).profilePhoto && (
                          <div>
                            <p className="text-[10px] text-slate-400 mb-1">Profile Photo</p>
                            <img
                              src={(selectedCustomer as any).profilePhoto}
                              alt="Profile"
                              className="w-14 h-14 object-cover rounded-xl border border-white/20"
                            />
                          </div>
                        )}
                        {selectedCustomer.aadhaarImage ? (
                          <div>
                            <p className="text-[10px] text-slate-400 mb-1">Aadhaar / Govt ID</p>
                            <img
                              src={selectedCustomer.aadhaarImage}
                              alt="Aadhaar"
                              className="w-16 h-12 object-cover rounded-lg border border-white/20"
                            />
                          </div>
                        ) : (
                          <div>
                            <p className="text-[10px] text-slate-400 mb-1">Aadhaar / Govt ID</p>
                            <span className="text-[11px] text-slate-500 italic">Not submitted</span>
                          </div>
                        )}
                        {selectedCustomer.selfieImage ? (
                          <div>
                            <p className="text-[10px] text-slate-400 mb-1">Live Selfie</p>
                            <img
                              src={selectedCustomer.selfieImage}
                              alt="Selfie"
                              className="w-12 h-12 object-cover rounded-full border border-white/20"
                            />
                          </div>
                        ) : (
                          <div>
                            <p className="text-[10px] text-slate-400 mb-1">Live Selfie</p>
                            <span className="text-[11px] text-slate-500 italic">Not submitted</span>
                          </div>
                        )}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-400 italic p-2 rounded-lg bg-white/5">
                        No KYC verification data available / Not submitted
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* Bookings by this customer */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Customer Bookings History ({customerBookings.length})
                </h4>
                {customerBookings.length === 0 ? (
                  <p className="text-xs text-slate-500 italic p-3 rounded-xl bg-white/5">No bookings logged for this user yet.</p>
                ) : (
                  <div className="space-y-2">
                    {customerBookings.map((b) => (
                      <div key={b.id} className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between text-xs">
                        <div>
                          <span className="font-bold text-white block">#{b.id} with {b.companionName}</span>
                          <span className="text-[11px] text-slate-400">{b.date} • {b.venue}</span>
                        </div>
                        <div className="text-right">
                          <span className="font-bold text-white block">₹{b.totalFee}</span>
                          <span className="text-[10px] uppercase font-semibold text-[#fd8a42]">{b.status}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Status Change Controls */}
              <div className="flex items-center justify-between pt-4 border-t border-white/10">
                <div className="text-xs text-slate-400">
                  Current Status: <span className="font-bold text-white capitalize">{selectedCustomer.status}</span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      updateCustomerStatus(selectedCustomer.id, 'active');
                      setSelectedCustomer({ ...selectedCustomer, status: 'active' });
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      selectedCustomer.status === 'active'
                        ? 'bg-emerald-500 text-white'
                        : 'bg-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    Activate
                  </button>

                  <button
                    onClick={() => {
                      updateCustomerStatus(selectedCustomer.id, 'suspended');
                      setSelectedCustomer({ ...selectedCustomer, status: 'suspended' });
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      selectedCustomer.status === 'suspended'
                        ? 'bg-amber-500 text-black'
                        : 'bg-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    Suspend
                  </button>

                  <button
                    onClick={() => {
                      updateCustomerStatus(selectedCustomer.id, 'blocked');
                      setSelectedCustomer({ ...selectedCustomer, status: 'blocked' });
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      selectedCustomer.status === 'blocked'
                        ? 'bg-red-500 text-white'
                        : 'bg-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    Block User
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
