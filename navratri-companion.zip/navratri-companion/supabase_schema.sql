-- ============================================================================
-- NAVRATRI COMPANION — SUPABASE POSTGRESQL PRODUCTION DATABASE SCHEMA
-- Execute this script in your Supabase Project -> SQL Editor
-- ============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. USERS TABLE
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  password_hash TEXT,
  role VARCHAR(50) DEFAULT 'user' CHECK (role IN ('user', 'companion', 'admin', 'owner')),
  city VARCHAR(255) DEFAULT 'Ahmedabad',
  account_status VARCHAR(50) DEFAULT 'pending' CHECK (account_status IN ('pending', 'active', 'suspended', 'blocked', 'inactive')),
  payment_status VARCHAR(50) DEFAULT 'pending' CHECK (payment_status IN ('pending', 'approved', 'rejected', 'pending_payment')),
  fee_paid BOOLEAN DEFAULT FALSE,
  profile_status VARCHAR(50) DEFAULT 'created',
  verification_status VARCHAR(50) DEFAULT 'id_submitted',
  aadhaar_image TEXT,
  selfie_image TEXT,
  policy_consent JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast user queries
CREATE INDEX IF NOT EXISTS idx_users_user_id ON public.users(user_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON public.users(email);
CREATE INDEX IF NOT EXISTS idx_users_account_status ON public.users(account_status);
CREATE INDEX IF NOT EXISTS idx_users_payment_status ON public.users(payment_status);

-- 2. REGISTRATION PAYMENTS TABLE
CREATE TABLE IF NOT EXISTS public.registration_payments (
  id VARCHAR(255) PRIMARY KEY,
  user_id VARCHAR(255) NOT NULL REFERENCES public.users(user_id) ON DELETE CASCADE,
  amount NUMERIC(10, 2) DEFAULT 499.00,
  payment_method VARCHAR(50) DEFAULT 'UPI',
  payment_reference VARCHAR(255) NOT NULL,
  payment_status VARCHAR(50) DEFAULT 'PENDING' CHECK (payment_status IN ('PENDING', 'APPROVED', 'REJECTED')),
  submitted_at TIMESTAMPTZ DEFAULT NOW(),
  approved_at TIMESTAMPTZ,
  approved_by VARCHAR(255),
  rejected_at TIMESTAMPTZ,
  rejection_reason TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for payment queries
CREATE INDEX IF NOT EXISTS idx_reg_payments_user_id ON public.registration_payments(user_id);
CREATE INDEX IF NOT EXISTS idx_reg_payments_status ON public.registration_payments(payment_status);
CREATE INDEX IF NOT EXISTS idx_reg_payments_ref ON public.registration_payments(payment_reference);

-- 3. USER PROFILES TABLE
CREATE TABLE IF NOT EXISTS public.user_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id VARCHAR(255) UNIQUE NOT NULL REFERENCES public.users(user_id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  city VARCHAR(255) DEFAULT 'Ahmedabad',
  age INTEGER,
  gender VARCHAR(50),
  bio TEXT,
  emergency_contact_name VARCHAR(255),
  emergency_contact_phone VARCHAR(50),
  emergency_contact_relation VARCHAR(100),
  preferred_locations TEXT[],
  preferred_garba_style VARCHAR(100),
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON public.user_profiles(user_id);

-- 4. BOOKINGS TABLE
CREATE TABLE IF NOT EXISTS public.bookings (
  id VARCHAR(255) PRIMARY KEY,
  user_id VARCHAR(255) NOT NULL,
  companion_id VARCHAR(255) NOT NULL,
  event_date VARCHAR(50) NOT NULL,
  duration_hours INTEGER NOT NULL,
  total_price NUMERIC(10, 2) NOT NULL,
  advance_paid NUMERIC(10, 2) NOT NULL,
  remaining_payout NUMERIC(10, 2) NOT NULL,
  platform_fee NUMERIC(10, 2) NOT NULL,
  venue_name VARCHAR(255) NOT NULL,
  venue_address TEXT,
  status VARCHAR(50) DEFAULT 'confirmed',
  booking_code VARCHAR(50),
  completion_otp VARCHAR(10),
  payment_reference VARCHAR(255),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. COMPLAINTS & GRIEVANCES TABLE
CREATE TABLE IF NOT EXISTS public.complaints (
  id VARCHAR(255) PRIMARY KEY,
  user_id VARCHAR(255) NOT NULL,
  user_name VARCHAR(255) NOT NULL,
  category VARCHAR(100) NOT NULL,
  description TEXT NOT NULL,
  status VARCHAR(50) DEFAULT 'open',
  priority VARCHAR(50) DEFAULT 'medium',
  resolution_notes TEXT,
  resolved_at TIMESTAMPTZ,
  resolved_by VARCHAR(255),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  action VARCHAR(255) NOT NULL,
  category VARCHAR(100) NOT NULL,
  details TEXT NOT NULL,
  actor_id VARCHAR(255) DEFAULT 'system',
  ip_address VARCHAR(100),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Realtime publication enablement for Supabase
ALTER PUBLICATION supabase_realtime ADD TABLE public.users;
ALTER PUBLICATION supabase_realtime ADD TABLE public.registration_payments;
ALTER PUBLICATION supabase_realtime ADD TABLE public.user_profiles;
ALTER PUBLICATION supabase_realtime ADD TABLE public.bookings;
