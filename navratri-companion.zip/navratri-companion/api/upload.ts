import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { parseRequestBody } from './auth/_authUtils.ts';
import { getSupabaseClient } from './_db.ts';

const UPLOADS_DIR = path.resolve(process.cwd(), '.data', 'uploads');

// Ensure upload directory exists
try {
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
} catch (e) {
  console.warn('Could not initialize uploads dir:', e);
}

const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

export default async function handler(req: any, res: any) {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');

  if (req.method !== 'POST') {
    res.statusCode = 405;
    return res.end(JSON.stringify({ success: false, errorMessage: 'Method Not Allowed' }));
  }

  try {
    const body = await parseRequestBody(req);
    const { dataUri, fileName = 'upload.jpg', fileType } = body;

    if (!dataUri || typeof dataUri !== 'string') {
      res.statusCode = 400;
      return res.end(
        JSON.stringify({
          success: false,
          errorMessage: 'No image data provided. Please select a valid photo.',
        })
      );
    }

    // Parse data URI: format data:[<mediatype>][;base64],<data>
    const matches = dataUri.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.+)$/);
    let mimeType = fileType || 'image/jpeg';
    let base64Data = dataUri;

    if (matches && matches.length === 3) {
      mimeType = matches[1].toLowerCase();
      base64Data = matches[2];
    } else if (dataUri.includes('base64,')) {
      const parts = dataUri.split('base64,');
      base64Data = parts[1];
    }

    // Validate MIME type
    if (!ALLOWED_MIME_TYPES.includes(mimeType)) {
      res.statusCode = 400;
      return res.end(
        JSON.stringify({
          success: false,
          errorMessage: 'Invalid file type. Only JPEG, PNG, and WebP images are permitted.',
        })
      );
    }

    // Convert to buffer and check size
    const buffer = Buffer.from(base64Data, 'base64');
    if (buffer.length > MAX_FILE_SIZE) {
      res.statusCode = 400;
      return res.end(
        JSON.stringify({
          success: false,
          errorMessage: 'File size exceeds 5MB limit. Please upload an image under 5MB.',
        })
      );
    }

    if (buffer.length < 100) {
      res.statusCode = 400;
      return res.end(
        JSON.stringify({
          success: false,
          errorMessage: 'Image data is invalid or corrupted.',
        })
      );
    }

    // Determine extension
    let ext = 'jpg';
    if (mimeType === 'image/png') ext = 'png';
    else if (mimeType === 'image/webp') ext = 'webp';

    const uniqueId = `img_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    const targetFilename = `${uniqueId}.${ext}`;

    // 1. Production: Upload to Supabase Storage if configured
    const supabase = getSupabaseClient();
    if (supabase) {
      try {
        const isKyc =
          fileName.toLowerCase().includes('aadhaar') ||
          fileName.toLowerCase().includes('id_') ||
          fileName.toLowerCase().includes('kyc') ||
          body.category === 'kyc' ||
          body.category === 'document';

        const bucket = isKyc ? 'kyc-documents' : 'profile-photos';

        // Try ensuring bucket exists
        try {
          await supabase.storage.createBucket(bucket, { public: !isKyc });
        } catch {}

        const filePath = `${uniqueId}.${ext}`;
        const { data: uploadRes, error: uploadErr } = await supabase.storage
          .from(bucket)
          .upload(filePath, buffer, {
            contentType: mimeType,
            upsert: true,
          });

        if (!uploadErr && uploadRes) {
          let finalUrl = '';
          if (isKyc) {
            // Private bucket: generate signed URL for authorized access
            const { data: signedData } = await supabase.storage
              .from(bucket)
              .createSignedUrl(filePath, 60 * 60 * 24 * 365);
            finalUrl = signedData?.signedUrl || '';
          } else {
            // Public bucket for profile photos
            const { data: pubData } = supabase.storage
              .from(bucket)
              .getPublicUrl(filePath);
            finalUrl = pubData.publicUrl;
          }

          if (finalUrl) {
            res.statusCode = 200;
            return res.end(
              JSON.stringify({
                success: true,
                url: finalUrl,
                fileName: targetFilename,
                size: buffer.length,
                mimeType: mimeType,
                storage: 'supabase',
              })
            );
          }
        }
      } catch (sbErr) {
        console.warn('Supabase storage attempt note:', sbErr);
      }
    }

    // 2. Fallback for Local Dev / Temporary Environment
    try {
      const targetPath = path.join(UPLOADS_DIR, targetFilename);
      fs.writeFileSync(targetPath, buffer);
    } catch {
      try {
        const tmpPath = path.join('/tmp', targetFilename);
        fs.writeFileSync(tmpPath, buffer);
      } catch {}
    }

    const publicUrl = `/api/uploads/${targetFilename}`;

    res.statusCode = 200;
    return res.end(
      JSON.stringify({
        success: true,
        url: publicUrl,
        fileName: targetFilename,
        size: buffer.length,
        mimeType: mimeType,
        storage: 'local',
      })
    );
  } catch (err: any) {
    console.error('File upload error:', err);
    res.statusCode = 500;
    return res.end(
      JSON.stringify({
        success: false,
        errorMessage: 'Image upload failed. Please try again.',
      })
    );
  }
}

// Serve uploaded image file
export function serveUpload(req: any, res: any): boolean {
  const url = (req.url || '').split('?')[0];
  if (!url.startsWith('/api/uploads/')) {
    return false;
  }

  const filename = path.basename(url);
  // Basic security sanitization: only alphanumeric + dot + underscore
  if (!/^[a-zA-Z0-9_.-]+$/.test(filename)) {
    res.statusCode = 400;
    res.end('Bad Request');
    return true;
  }

  const filePath = path.join(UPLOADS_DIR, filename);
  if (!fs.existsSync(filePath)) {
    res.statusCode = 404;
    res.end('File Not Found');
    return true;
  }

  const ext = path.extname(filename).toLowerCase();
  let contentType = 'image/jpeg';
  if (ext === '.png') contentType = 'image/png';
  else if (ext === '.webp') contentType = 'image/webp';

  res.setHeader('Content-Type', contentType);
  res.setHeader('Cache-Control', 'public, max-age=86400');
  const stream = fs.createReadStream(filePath);
  stream.pipe(res);
  return true;
}
