import fs from 'fs';
import path from 'path';
import { createClient } from '@supabase/supabase-js';
import pg from 'pg';

export interface UserRecord {
  id: string;
  userId: string;
  name: string;
  email: string;
  phone: string;
  mobile?: string;
  password?: string;
  role: 'customer' | 'companion' | 'user' | 'admin' | 'owner';
  city: string;
  accountStatus: 'pending' | 'active' | 'suspended' | 'blocked' | 'inactive' | 'pending_payment' | 'pending_approval' | 'payment_rejected';
  paymentStatus: 'pending' | 'approved' | 'rejected' | 'pending_payment';
  feePaid: boolean;
  profileStatus: string;
  verificationStatus: string;
  loginEnabled?: boolean;
  profilePhoto?: string;
  dateOfBirth?: string;
  age?: number;
  bio?: string;
  languages?: string;
  garbaStyle?: string;
  availableCities?: string;
  hourlyRate?: number;
  idDocument?: string;
  idDocumentType?: string;
  faceMatchScore?: string;
  phoneVerified?: boolean;
  reviewStatus?: string;
  aadhaarImage?: string;
  selfieImage?: string;
  approvedAt?: string | null;
  approvedBy?: string | null;
  rejectedAt?: string | null;
  rejectionReason?: string | null;
  paymentReference?: string;
  paymentSubmittedAt?: string;
  policyConsent?: any;
  createdAt: string;
  updatedAt?: string;
}

export interface HostApplicantRecord {
  id: string;
  userId: string;
  name: string;
  age: number;
  dateOfBirth?: string;
  city: string;
  area: string;
  localityArea?: string;
  garbaStyle: string;
  appliedAt: string;
  idDocument: string;
  aadhaarImage?: string;
  selfieImage?: string;
  profilePhoto?: string;
  avatar?: string;
  registrationFeePaid: boolean;
  faceMatchScore?: string;
  status: 'pending_review' | 'approved' | 'rejected';
  phone?: string;
  email?: string;
  experienceYears?: string;
  bio?: string;
  languages?: string;
  hourlyRate?: number;
  phoneVerified?: boolean;
  reviewStatus?: string;
}

export interface PaymentRecord {
  id: string;
  userId: string;
  amount: number;
  paymentMethod: string;
  paymentReference: string;
  paymentStatus: 'PENDING' | 'APPROVED' | 'REJECTED';
  submittedAt: string;
  approvedAt?: string | null;
  approvedBy?: string | null;
  rejectedAt?: string | null;
  rejectionReason?: string | null;
  createdAt: string;
  updatedAt?: string;
  notes?: string | null;
}

export interface UserProfileRecord {
  id?: string;
  userId: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  age?: number;
  gender?: string;
  bio?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyContactRelation?: string;
  preferredLocations?: string[];
  preferredGarbaStyle?: string;
  avatarUrl?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface BookingRecord {
  id: string;
  bookingReference: string;
  customerId: string;
  customerName: string;
  customerPhone?: string;
  companionId: string;
  companionName: string;
  companionPhone?: string;
  companionUpi?: string;
  companionAge?: number;
  companionCity?: string;
  companionAvatar?: string;
  date: string;
  rawDate?: string;
  timeSlot: string;
  durationPackage: '2 Hours' | '4 Hours' | string;
  venue: string;
  city: string;
  basePrice: number;
  platformFee: number;
  totalPrice: number;
  companionEarnings: number;
  status: 'PENDING_PAYMENT_VERIFICATION' | 'confirmed' | 'checked_in' | 'session_active' | 'completed' | 'cancelled';
  paymentStatus: 'PENDING' | 'PAID' | 'REFUNDED' | 'DISPUTED';
  paymentReference?: string;
  escrowStatus: string;
  completionOtp?: string;
  otpVerified?: boolean;
  checkInAt?: string;
  completedAt?: string;
  payoutStatus: 'escrow_held' | 'ready_to_pay' | 'PENDING_ADMIN_APPROVAL' | 'approved' | 'paid' | 'rejected';
  createdAt: string;
  updatedAt?: string;
}

export interface PayoutRecord {
  id: string;
  bookingId: string;
  companionId: string;
  companionName: string;
  companionUpi: string;
  amount: number;
  platformFee: number;
  grossAmount: number;
  status: 'PENDING_ADMIN_APPROVAL' | 'APPROVED' | 'PAID' | 'REJECTED';
  transactionReference?: string;
  approvedAt?: string;
  approvedBy?: string;
  paidAt?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface ComplaintRecord {
  id: string;
  bookingId?: string;
  reporterType: 'guest' | 'companion' | 'customer';
  reporterName: string;
  reporterPhone?: string;
  targetName: string;
  category: string;
  severity: 'low' | 'medium' | 'high' | 'urgent';
  status: 'open' | 'investigating' | 'resolved' | 'dismissed';
  subject: string;
  description: string;
  assignedAdmin?: string;
  resolutionNotes?: string;
  resolvedAt?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface DatabaseState {
  users: UserRecord[];
  payments: PaymentRecord[];
  profiles: UserProfileRecord[];
  applications: HostApplicantRecord[];
  bookings: BookingRecord[];
  payouts: PayoutRecord[];
  complaints: ComplaintRecord[];
  auditLogs: any[];
  companions: any[];
  settings: Record<string, any>;
}

// In-memory global store to share data across invocations within the same Node process
let memoryDb: DatabaseState = {
  users: [],
  payments: [],
  profiles: [],
  applications: [],
  bookings: [],
  payouts: [],
  complaints: [],
  auditLogs: [],
  companions: [],
  settings: {},
};

// Data file path for local/server persistence
const DATA_DIR = path.resolve(process.cwd(), '.data');
const DATA_FILE = path.join(DATA_DIR, 'production_db.json');

// Helper to determine active database engine
export const getSupabaseClient = () => {
  const url = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key =
    process.env.SUPABASE_SERVICE_ROLE_KEY ||
    process.env.SUPABASE_KEY ||
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (url && key) {
    try {
      return createClient(url, key);
    } catch (e) {
      console.warn('Failed to initialize Supabase client:', e);
    }
  }
  return null;
};

export const getPostgresPool = () => {
  const dbUrl =
    process.env.DATABASE_URL ||
    process.env.POSTGRES_URL ||
    process.env.POSTGRES_PRISMA_URL ||
    process.env.NEON_DATABASE_URL;

  if (dbUrl) {
    try {
      const { Pool } = pg;
      return new Pool({
        connectionString: dbUrl,
        ssl: dbUrl.includes('localhost') ? false : { rejectUnauthorized: false },
      });
    } catch (e) {
      console.warn('Failed to initialize Postgres pool:', e);
    }
  }
  return null;
};

// Read from JSON file
const readLocalDb = (): DatabaseState => {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const content = fs.readFileSync(DATA_FILE, 'utf-8');
      const parsed = JSON.parse(content);
      if (parsed && Array.isArray(parsed.users)) {
        memoryDb = {
          users: parsed.users || [],
          payments: parsed.payments || [],
          profiles: parsed.profiles || [],
          applications: parsed.applications || [],
          bookings: parsed.bookings || [],
          payouts: parsed.payouts || [],
          complaints: parsed.complaints || [],
          auditLogs: parsed.auditLogs || [],
          companions: parsed.companions || [],
          settings: parsed.settings || {},
        };
        return memoryDb;
      }
    }
  } catch (err) {
    console.warn('Could not read from local db file:', err);
  }
  return memoryDb;
};

// Write to JSON file
const writeLocalDb = (data: DatabaseState) => {
  memoryDb = data;
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    try {
      const tmpPath = '/tmp/production_db.json';
      fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf-8');
    } catch (tmpErr) {}
  }
};

// Auto-initialize schema if PostgreSQL is connected directly
let schemaInitialized = false;
export const initSchemaIfNeeded = async () => {
  if (schemaInitialized) return;
  const pool = getPostgresPool();
  if (pool) {
    try {
      await pool.query(`
        CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

        CREATE TABLE IF NOT EXISTS public.users (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          user_id VARCHAR(255) UNIQUE NOT NULL,
          name VARCHAR(255) NOT NULL,
          email VARCHAR(255) NOT NULL,
          phone VARCHAR(50),
          password_hash TEXT,
          role VARCHAR(50) DEFAULT 'customer',
          city VARCHAR(255) DEFAULT 'Ahmedabad',
          account_status VARCHAR(50) DEFAULT 'pending_payment',
          payment_status VARCHAR(50) DEFAULT 'pending',
          fee_paid BOOLEAN DEFAULT FALSE,
          profile_status VARCHAR(50) DEFAULT 'created',
          verification_status VARCHAR(50) DEFAULT 'id_submitted',
          profile_photo TEXT,
          date_of_birth TEXT,
          age INTEGER,
          bio TEXT,
          languages TEXT,
          garba_style TEXT,
          available_cities TEXT,
          hourly_rate NUMERIC(10, 2),
          id_document TEXT,
          face_match_score TEXT,
          phone_verified BOOLEAN DEFAULT FALSE,
          review_status TEXT,
          aadhaar_image TEXT,
          selfie_image TEXT,
          policy_consent JSONB,
          created_at TIMESTAMPTZ DEFAULT NOW(),
          updated_at TIMESTAMPTZ DEFAULT NOW()
        );

        -- Safe column additions for existing tables
        ALTER TABLE public.users ADD COLUMN IF NOT EXISTS profile_photo TEXT;
        ALTER TABLE public.users ADD COLUMN IF NOT EXISTS date_of_birth TEXT;
        ALTER TABLE public.users ADD COLUMN IF NOT EXISTS age INTEGER;
        ALTER TABLE public.users ADD COLUMN IF NOT EXISTS bio TEXT;
        ALTER TABLE public.users ADD COLUMN IF NOT EXISTS languages TEXT;
        ALTER TABLE public.users ADD COLUMN IF NOT EXISTS garba_style TEXT;
        ALTER TABLE public.users ADD COLUMN IF NOT EXISTS available_cities TEXT;
        ALTER TABLE public.users ADD COLUMN IF NOT EXISTS hourly_rate NUMERIC(10, 2);
        ALTER TABLE public.users ADD COLUMN IF NOT EXISTS id_document TEXT;
        ALTER TABLE public.users ADD COLUMN IF NOT EXISTS face_match_score TEXT;
        ALTER TABLE public.users ADD COLUMN IF NOT EXISTS phone_verified BOOLEAN DEFAULT FALSE;
        ALTER TABLE public.users ADD COLUMN IF NOT EXISTS review_status TEXT;

        CREATE TABLE IF NOT EXISTS public.host_applications (
          id VARCHAR(255) PRIMARY KEY,
          user_id VARCHAR(255) NOT NULL,
          name VARCHAR(255) NOT NULL,
          age INTEGER,
          date_of_birth TEXT,
          city VARCHAR(255) DEFAULT 'Ahmedabad',
          area VARCHAR(255),
          locality_area VARCHAR(255),
          garba_style VARCHAR(255),
          applied_at TIMESTAMPTZ DEFAULT NOW(),
          id_document VARCHAR(255),
          aadhaar_image TEXT,
          selfie_image TEXT,
          profile_photo TEXT,
          avatar TEXT,
          registration_fee_paid BOOLEAN DEFAULT FALSE,
          face_match_score TEXT DEFAULT 'Not performed',
          status VARCHAR(50) DEFAULT 'pending_review',
          phone VARCHAR(50),
          email VARCHAR(255),
          experience_years VARCHAR(50),
          bio TEXT,
          languages TEXT,
          hourly_rate NUMERIC(10, 2),
          phone_verified BOOLEAN DEFAULT FALSE,
          review_status VARCHAR(50) DEFAULT 'Pending Review',
          created_at TIMESTAMPTZ DEFAULT NOW(),
          updated_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS public.registration_payments (
          id VARCHAR(255) PRIMARY KEY,
          user_id VARCHAR(255) NOT NULL REFERENCES public.users(user_id) ON DELETE CASCADE,
          amount NUMERIC(10, 2) DEFAULT 499.00,
          payment_method VARCHAR(50) DEFAULT 'UPI',
          payment_reference VARCHAR(255) NOT NULL,
          payment_status VARCHAR(50) DEFAULT 'PENDING',
          submitted_at TIMESTAMPTZ DEFAULT NOW(),
          approved_at TIMESTAMPTZ,
          approved_by VARCHAR(255),
          rejected_at TIMESTAMPTZ,
          rejection_reason TEXT,
          created_at TIMESTAMPTZ DEFAULT NOW(),
          updated_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS public.user_profiles (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          user_id VARCHAR(255) UNIQUE NOT NULL REFERENCES public.users(user_id) ON DELETE CASCADE,
          name VARCHAR(255) NOT NULL,
          email VARCHAR(255) NOT NULL,
          phone VARCHAR(50),
          city VARCHAR(255) DEFAULT 'Ahmedabad',
          age INTEGER,
          gender VARCHAR(50),
          bio TEXT,
          emergency_contact_name VARCHAR(255),
          emergency_contact_phone VARCHAR(50),
          emergency_contact_relation VARCHAR(100),
          preferred_locations TEXT[],
          preferred_garba_style VARCHAR(100),
          avatar_url TEXT,
          created_at TIMESTAMPTZ DEFAULT NOW(),
          updated_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS public.bookings (
          id VARCHAR(255) PRIMARY KEY,
          booking_reference VARCHAR(255) UNIQUE NOT NULL,
          customer_id VARCHAR(255) NOT NULL,
          customer_name VARCHAR(255) NOT NULL,
          customer_phone VARCHAR(50),
          companion_id VARCHAR(255) NOT NULL,
          companion_name VARCHAR(255) NOT NULL,
          companion_phone VARCHAR(50),
          companion_upi VARCHAR(255),
          companion_age INTEGER,
          companion_city VARCHAR(255),
          companion_avatar TEXT,
          date TEXT NOT NULL,
          raw_date TEXT,
          time_slot TEXT NOT NULL,
          duration_package VARCHAR(50) NOT NULL,
          venue TEXT NOT NULL,
          city VARCHAR(255) DEFAULT 'Ahmedabad',
          base_price NUMERIC(10, 2) NOT NULL,
          platform_fee NUMERIC(10, 2) NOT NULL DEFAULT 50.00,
          total_price NUMERIC(10, 2) NOT NULL,
          companion_earnings NUMERIC(10, 2) NOT NULL,
          status VARCHAR(50) DEFAULT 'PENDING_PAYMENT_VERIFICATION',
          payment_status VARCHAR(50) DEFAULT 'PENDING',
          payment_reference VARCHAR(255),
          escrow_status VARCHAR(50) DEFAULT 'Held in Escrow',
          completion_otp VARCHAR(10),
          otp_verified BOOLEAN DEFAULT FALSE,
          check_in_at TIMESTAMPTZ,
          completed_at TIMESTAMPTZ,
          payout_status VARCHAR(50) DEFAULT 'escrow_held',
          created_at TIMESTAMPTZ DEFAULT NOW(),
          updated_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS public.payouts (
          id VARCHAR(255) PRIMARY KEY,
          booking_id VARCHAR(255) NOT NULL,
          companion_id VARCHAR(255) NOT NULL,
          companion_name VARCHAR(255) NOT NULL,
          companion_upi VARCHAR(255) NOT NULL,
          amount NUMERIC(10, 2) NOT NULL,
          platform_fee NUMERIC(10, 2) DEFAULT 0,
          gross_amount NUMERIC(10, 2) NOT NULL,
          status VARCHAR(50) DEFAULT 'PENDING_ADMIN_APPROVAL',
          transaction_reference VARCHAR(255),
          approved_at TIMESTAMPTZ,
          approved_by VARCHAR(255),
          paid_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ DEFAULT NOW(),
          updated_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS public.complaints (
          id VARCHAR(255) PRIMARY KEY,
          booking_id VARCHAR(255),
          reporter_type VARCHAR(50) NOT NULL,
          reporter_name VARCHAR(255) NOT NULL,
          reporter_phone VARCHAR(50),
          target_name VARCHAR(255) NOT NULL,
          category VARCHAR(100) NOT NULL,
          severity VARCHAR(50) DEFAULT 'medium',
          status VARCHAR(50) DEFAULT 'open',
          subject TEXT NOT NULL,
          description TEXT NOT NULL,
          assigned_admin VARCHAR(255),
          resolution_notes TEXT,
          resolved_at TIMESTAMPTZ,
          created_at TIMESTAMPTZ DEFAULT NOW(),
          updated_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS public.kyc_verifications (
          id VARCHAR(255) PRIMARY KEY,
          user_id VARCHAR(255) UNIQUE NOT NULL,
          document_type VARCHAR(100) DEFAULT 'Aadhaar / Govt ID',
          document_url TEXT,
          selfie_url TEXT,
          verification_status VARCHAR(50) DEFAULT 'PENDING_REVIEW',
          phone_verified BOOLEAN DEFAULT FALSE,
          face_match_score TEXT DEFAULT 'Not performed',
          reviewed_by VARCHAR(255),
          reviewed_at TIMESTAMPTZ,
          rejection_reason TEXT,
          created_at TIMESTAMPTZ DEFAULT NOW(),
          updated_at TIMESTAMPTZ DEFAULT NOW()
        );
      `);
      schemaInitialized = true;
    } catch (e) {
      console.warn('Postgres schema init note:', e);
    }
  }
};

// ==========================================
// CENTRAL DATABASE CRUD OPERATIONS
// ==========================================

export async function getAllUsers(): Promise<UserRecord[]> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      const res = await pool.query('SELECT * FROM public.users ORDER BY created_at DESC');
      return res.rows.map((row) => ({
        id: row.id,
        userId: row.user_id,
        name: row.name,
        email: row.email,
        phone: row.phone,
        mobile: row.phone,
        password: row.password_hash,
        role: (row.role || 'customer') as any,
        city: row.city || 'Ahmedabad',
        accountStatus: (row.account_status || 'pending_payment').toLowerCase() as any,
        paymentStatus: (row.payment_status || 'pending').toLowerCase() as any,
        feePaid: Boolean(row.fee_paid),
        profileStatus: row.profile_status || 'created',
        verificationStatus: row.verification_status || 'id_submitted',
        loginEnabled: row.account_status === 'active' && Boolean(row.fee_paid),
        profilePhoto: row.profile_photo || '',
        dateOfBirth: row.date_of_birth,
        age: row.age ? Number(row.age) : undefined,
        bio: row.bio || '',
        languages: row.languages || '',
        garbaStyle: row.garba_style || '',
        availableCities: row.available_cities || '',
        hourlyRate: row.hourly_rate ? Number(row.hourly_rate) : undefined,
        idDocument: row.id_document || '',
        faceMatchScore: row.face_match_score || 'Not performed',
        phoneVerified: Boolean(row.phone_verified),
        reviewStatus: row.review_status || 'Pending Review',
        aadhaarImage: row.aadhaar_image,
        selfieImage: row.selfie_image,
        policyConsent: row.policy_consent,
        paymentReference: row.payment_reference,
        paymentSubmittedAt: row.payment_submitted_at,
        approvedAt: row.approved_at,
        approvedBy: row.approved_by,
        rejectedAt: row.rejected_at,
        rejectionReason: row.rejection_reason,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
      }));
    } catch (e) {
      console.warn('Postgres fetch users error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .order('created_at', { ascending: false });
      if (!error && data) {
        return data.map((row: any) => ({
          id: row.id,
          userId: row.user_id,
          name: row.name,
          email: row.email,
          phone: row.phone,
          mobile: row.phone,
          password: row.password_hash,
          role: (row.role || 'customer') as any,
          city: row.city || 'Ahmedabad',
          accountStatus: (row.account_status || 'pending_payment').toLowerCase() as any,
          paymentStatus: (row.payment_status || 'pending').toLowerCase() as any,
          feePaid: Boolean(row.fee_paid),
          profileStatus: row.profile_status || 'created',
          verificationStatus: row.verification_status || 'id_submitted',
          loginEnabled: row.account_status === 'active' && Boolean(row.fee_paid),
          aadhaarImage: row.aadhaar_image,
          selfieImage: row.selfie_image,
          policyConsent: row.policy_consent,
          paymentReference: row.payment_reference,
          paymentSubmittedAt: row.payment_submitted_at,
          approvedAt: row.approved_at,
          approvedBy: row.approved_by,
          rejectedAt: row.rejected_at,
          rejectionReason: row.rejection_reason,
          createdAt: row.created_at,
          updatedAt: row.updated_at,
        }));
      }
    } catch (e) {}
  }

  const db = readLocalDb();
  return db.users;
}

export async function getUserByIdentifier(identifier: string): Promise<UserRecord | null> {
  const clean = (identifier || '').trim().toLowerCase();
  const users = await getAllUsers();
  return (
    users.find((u) => {
      const uId = (u.userId || '').trim().toLowerCase();
      const uEmail = (u.email || '').trim().toLowerCase();
      const uPhone = (u.phone || u.mobile || '').replace(/[^0-9]/g, '');
      const queryPhone = clean.replace(/[^0-9]/g, '');
      const isPhoneMatch = queryPhone.length >= 10 && uPhone.includes(queryPhone);
      return uId === clean || uEmail === clean || isPhoneMatch;
    }) || null
  );
}

export async function createUser(user: UserRecord): Promise<UserRecord> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      await pool.query(
        `INSERT INTO public.users (
          user_id, name, email, phone, password_hash, role, city,
          account_status, payment_status, fee_paid, profile_status, verification_status,
          profile_photo, date_of_birth, age, bio, languages, garba_style, available_cities,
          hourly_rate, id_document, face_match_score, phone_verified, review_status,
          aadhaar_image, selfie_image, policy_consent, created_at, updated_at
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12,
          $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24,
          $25, $26, $27, $28, $29
        )
        ON CONFLICT (user_id) DO UPDATE SET
          name = EXCLUDED.name,
          email = EXCLUDED.email,
          phone = EXCLUDED.phone,
          password_hash = EXCLUDED.password_hash,
          role = EXCLUDED.role,
          account_status = EXCLUDED.account_status,
          payment_status = EXCLUDED.payment_status,
          fee_paid = EXCLUDED.fee_paid,
          profile_photo = EXCLUDED.profile_photo,
          date_of_birth = EXCLUDED.date_of_birth,
          age = EXCLUDED.age,
          bio = EXCLUDED.bio,
          languages = EXCLUDED.languages,
          garba_style = EXCLUDED.garba_style,
          available_cities = EXCLUDED.available_cities,
          hourly_rate = EXCLUDED.hourly_rate,
          id_document = EXCLUDED.id_document,
          face_match_score = EXCLUDED.face_match_score,
          phone_verified = EXCLUDED.phone_verified,
          review_status = EXCLUDED.review_status,
          updated_at = NOW()`,
        [
          user.userId,
          user.name,
          user.email,
          user.phone || user.mobile,
          user.password,
          user.role || 'customer',
          user.city || 'Ahmedabad',
          user.accountStatus || 'pending_payment',
          user.paymentStatus || 'pending',
          user.feePaid ?? false,
          user.profileStatus || 'created',
          user.verificationStatus || 'id_submitted',
          user.profilePhoto || '',
          user.dateOfBirth || null,
          user.age || null,
          user.bio || '',
          user.languages || '',
          user.garbaStyle || '',
          user.availableCities || '',
          user.hourlyRate || null,
          user.idDocument || '',
          user.faceMatchScore || 'Not performed',
          user.phoneVerified ?? false,
          user.reviewStatus || 'Pending Review',
          user.aadhaarImage || '',
          user.selfieImage || '',
          JSON.stringify(user.policyConsent || {}),
          user.createdAt || new Date().toISOString(),
          new Date().toISOString(),
        ]
      );
    } catch (e) {
      console.warn('Postgres createUser error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('users').upsert({
        user_id: user.userId,
        name: user.name,
        email: user.email,
        phone: user.phone || user.mobile,
        password_hash: user.password,
        role: user.role || 'user',
        city: user.city || 'Ahmedabad',
        account_status: user.accountStatus || 'pending',
        payment_status: user.paymentStatus || 'pending',
        fee_paid: user.feePaid ?? false,
        profile_status: user.profileStatus || 'created',
        verification_status: user.verificationStatus || 'id_submitted',
        aadhaar_image: user.aadhaarImage || '',
        selfie_image: user.selfieImage || '',
        policy_consent: user.policyConsent || {},
        created_at: user.createdAt || new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
    } catch (e) {}
  }

  // Sync internal memory/file
  const db = readLocalDb();
  const existingIndex = db.users.findIndex(
    (u) => u.userId.toLowerCase() === user.userId.toLowerCase() || u.id === user.id
  );
  if (existingIndex >= 0) {
    db.users[existingIndex] = { ...db.users[existingIndex], ...user };
  } else {
    db.users = [user, ...db.users];
  }
  writeLocalDb(db);
  return user;
}

export async function updateUser(userId: string, updates: Partial<UserRecord>): Promise<UserRecord | null> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      const setClauses: string[] = [];
      const values: any[] = [];
      let i = 1;

      if (updates.accountStatus !== undefined) {
        setClauses.push(`account_status = $${i++}`);
        values.push(updates.accountStatus.toLowerCase());
      }
      if (updates.paymentStatus !== undefined) {
        setClauses.push(`payment_status = $${i++}`);
        values.push(updates.paymentStatus.toLowerCase());
      }
      if (updates.feePaid !== undefined) {
        setClauses.push(`fee_paid = $${i++}`);
        values.push(updates.feePaid);
      }
      if (updates.profileStatus !== undefined) {
        setClauses.push(`profile_status = $${i++}`);
        values.push(updates.profileStatus);
      }
      if (updates.verificationStatus !== undefined) {
        setClauses.push(`verification_status = $${i++}`);
        values.push(updates.verificationStatus);
      }

      setClauses.push(`updated_at = NOW()`);

      if (setClauses.length > 0) {
        values.push(userId);
        await pool.query(
          `UPDATE public.users SET ${setClauses.join(', ')} WHERE LOWER(user_id) = LOWER($${i})`,
          values
        );
      }
    } catch (e) {
      console.warn('Postgres updateUser error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      const supabaseUpdates: any = { updated_at: new Date().toISOString() };
      if (updates.accountStatus) supabaseUpdates.account_status = updates.accountStatus.toLowerCase();
      if (updates.paymentStatus) supabaseUpdates.payment_status = updates.paymentStatus.toLowerCase();
      if (updates.feePaid !== undefined) supabaseUpdates.fee_paid = updates.feePaid;
      if (updates.profileStatus) supabaseUpdates.profile_status = updates.profileStatus;
      if (updates.verificationStatus) supabaseUpdates.verification_status = updates.verificationStatus;

      await supabase.from('users').update(supabaseUpdates).ilike('user_id', userId);
    } catch (e) {}
  }

  const db = readLocalDb();
  const targetIndex = db.users.findIndex(
    (u) => u.userId.toLowerCase() === userId.toLowerCase() || u.id === userId
  );
  if (targetIndex >= 0) {
    db.users[targetIndex] = { ...db.users[targetIndex], ...updates };
    writeLocalDb(db);
    return db.users[targetIndex];
  }
  return null;
}

export async function getAllPayments(): Promise<PaymentRecord[]> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      const res = await pool.query('SELECT * FROM public.registration_payments ORDER BY created_at DESC');
      return res.rows.map((row) => ({
        id: row.id,
        userId: row.user_id,
        amount: Number(row.amount),
        paymentMethod: row.payment_method,
        paymentReference: row.payment_reference,
        paymentStatus: row.payment_status,
        submittedAt: row.submitted_at,
        approvedAt: row.approved_at,
        approvedBy: row.approved_by,
        rejectedAt: row.rejected_at,
        rejectionReason: row.rejection_reason,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
      }));
    } catch (e) {
      console.warn('Postgres fetch payments error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('registration_payments')
        .select('*')
        .order('created_at', { ascending: false });
      if (!error && data) {
        return data.map((row: any) => ({
          id: row.id,
          userId: row.user_id,
          amount: Number(row.amount),
          paymentMethod: row.payment_method,
          paymentReference: row.payment_reference,
          paymentStatus: row.payment_status,
          submittedAt: row.submitted_at,
          approvedAt: row.approved_at,
          approvedBy: row.approved_by,
          rejectedAt: row.rejected_at,
          rejectionReason: row.rejection_reason,
          createdAt: row.created_at,
          updatedAt: row.updated_at,
        }));
      }
    } catch (e) {}
  }

  const db = readLocalDb();
  return db.payments;
}

export async function createPayment(payment: PaymentRecord): Promise<PaymentRecord> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      await pool.query(
        `INSERT INTO public.registration_payments (
          id, user_id, amount, payment_method, payment_reference, payment_status,
          submitted_at, approved_at, approved_by, rejected_at, rejection_reason, created_at, updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        ON CONFLICT (id) DO UPDATE SET
          payment_status = EXCLUDED.payment_status,
          payment_reference = EXCLUDED.payment_reference,
          approved_at = EXCLUDED.approved_at,
          approved_by = EXCLUDED.approved_by,
          rejected_at = EXCLUDED.rejected_at,
          rejection_reason = EXCLUDED.rejection_reason,
          updated_at = NOW()`,
        [
          payment.id,
          payment.userId,
          payment.amount || 499,
          payment.paymentMethod || 'UPI',
          payment.paymentReference,
          payment.paymentStatus || 'PENDING',
          payment.submittedAt || new Date().toISOString(),
          payment.approvedAt || null,
          payment.approvedBy || null,
          payment.rejectedAt || null,
          payment.rejectionReason || null,
          payment.createdAt || new Date().toISOString(),
          new Date().toISOString(),
        ]
      );
    } catch (e) {
      console.warn('Postgres createPayment error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('registration_payments').upsert({
        id: payment.id,
        user_id: payment.userId,
        amount: payment.amount || 499,
        payment_method: payment.paymentMethod || 'UPI',
        payment_reference: payment.paymentReference,
        payment_status: payment.paymentStatus || 'PENDING',
        submitted_at: payment.submittedAt || new Date().toISOString(),
        approved_at: payment.approvedAt || null,
        approved_by: payment.approvedBy || null,
        rejected_at: payment.rejectedAt || null,
        rejection_reason: payment.rejectionReason || null,
        created_at: payment.createdAt || new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
    } catch (e) {}
  }

  const db = readLocalDb();
  const existingIdx = db.payments.findIndex(
    (p) => p.id === payment.id || (p.userId.toLowerCase() === payment.userId.toLowerCase() && p.paymentStatus === 'PENDING')
  );
  if (existingIdx >= 0) {
    db.payments[existingIdx] = { ...db.payments[existingIdx], ...payment };
  } else {
    db.payments = [payment, ...db.payments];
  }
  writeLocalDb(db);
  return payment;
}

export async function updatePayment(
  idOrUserId: string,
  updates: Partial<PaymentRecord>
): Promise<PaymentRecord | null> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      const setClauses: string[] = [];
      const values: any[] = [];
      let i = 1;

      if (updates.paymentStatus !== undefined) {
        setClauses.push(`payment_status = $${i++}`);
        values.push(updates.paymentStatus);
      }
      if (updates.approvedAt !== undefined) {
        setClauses.push(`approved_at = $${i++}`);
        values.push(updates.approvedAt);
      }
      if (updates.approvedBy !== undefined) {
        setClauses.push(`approved_by = $${i++}`);
        values.push(updates.approvedBy);
      }
      if (updates.rejectedAt !== undefined) {
        setClauses.push(`rejected_at = $${i++}`);
        values.push(updates.rejectedAt);
      }
      if (updates.rejectionReason !== undefined) {
        setClauses.push(`rejection_reason = $${i++}`);
        values.push(updates.rejectionReason);
      }

      setClauses.push(`updated_at = NOW()`);

      if (setClauses.length > 0) {
        values.push(idOrUserId);
        await pool.query(
          `UPDATE public.registration_payments SET ${setClauses.join(', ')} WHERE id = $${i} OR LOWER(user_id) = LOWER($${i})`,
          values
        );
      }
    } catch (e) {
      console.warn('Postgres updatePayment error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      const supabaseUpdates: any = { updated_at: new Date().toISOString() };
      if (updates.paymentStatus) supabaseUpdates.payment_status = updates.paymentStatus;
      if (updates.approvedAt !== undefined) supabaseUpdates.approved_at = updates.approvedAt;
      if (updates.approvedBy !== undefined) supabaseUpdates.approved_by = updates.approvedBy;
      if (updates.rejectedAt !== undefined) supabaseUpdates.rejected_at = updates.rejectedAt;
      if (updates.rejectionReason !== undefined) supabaseUpdates.rejection_reason = updates.rejectionReason;

      await supabase
        .from('registration_payments')
        .update(supabaseUpdates)
        .or(`id.eq.${idOrUserId},user_id.eq.${idOrUserId}`);
    } catch (e) {}
  }

  const db = readLocalDb();
  const targetIdx = db.payments.findIndex(
    (p) => p.id === idOrUserId || p.userId.toLowerCase() === idOrUserId.toLowerCase()
  );
  if (targetIdx >= 0) {
    db.payments[targetIdx] = { ...db.payments[targetIdx], ...updates };
    writeLocalDb(db);
    return db.payments[targetIdx];
  }
  return null;
}

// User Profile CRUD Operations
export async function getUserProfile(userId: string): Promise<UserProfileRecord | null> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      const res = await pool.query('SELECT * FROM public.user_profiles WHERE LOWER(user_id) = LOWER($1)', [userId]);
      if (res.rows.length > 0) {
        const row = res.rows[0];
        return {
          id: row.id,
          userId: row.user_id,
          name: row.name,
          email: row.email,
          phone: row.phone,
          city: row.city,
          age: row.age,
          gender: row.gender,
          bio: row.bio,
          emergencyContactName: row.emergency_contact_name,
          emergencyContactPhone: row.emergency_contact_phone,
          emergencyContactRelation: row.emergency_contact_relation,
          preferredLocations: row.preferred_locations,
          preferredGarbaStyle: row.preferred_garba_style,
          avatarUrl: row.avatar_url,
          createdAt: row.created_at,
          updatedAt: row.updated_at,
        };
      }
    } catch (e) {}
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .ilike('user_id', userId)
        .single();
      if (!error && data) {
        return {
          id: data.id,
          userId: data.user_id,
          name: data.name,
          email: data.email,
          phone: data.phone,
          city: data.city,
          age: data.age,
          gender: data.gender,
          bio: data.bio,
          emergencyContactName: data.emergency_contact_name,
          emergencyContactPhone: data.emergency_contact_phone,
          emergencyContactRelation: data.emergency_contact_relation,
          preferredLocations: data.preferred_locations,
          preferredGarbaStyle: data.preferred_garba_style,
          avatarUrl: data.avatar_url,
          createdAt: data.created_at,
          updatedAt: data.updated_at,
        };
      }
    } catch (e) {}
  }

  const db = readLocalDb();
  return db.profiles?.find((p) => p.userId.toLowerCase() === userId.toLowerCase()) || null;
}

export async function upsertUserProfile(profile: UserProfileRecord): Promise<UserProfileRecord> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      await pool.query(
        `INSERT INTO public.user_profiles (
          user_id, name, email, phone, city, age, gender, bio,
          emergency_contact_name, emergency_contact_phone, emergency_contact_relation,
          preferred_locations, preferred_garba_style, avatar_url, updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, NOW())
        ON CONFLICT (user_id) DO UPDATE SET
          name = EXCLUDED.name,
          email = EXCLUDED.email,
          phone = EXCLUDED.phone,
          city = EXCLUDED.city,
          age = EXCLUDED.age,
          gender = EXCLUDED.gender,
          bio = EXCLUDED.bio,
          emergency_contact_name = EXCLUDED.emergency_contact_name,
          emergency_contact_phone = EXCLUDED.emergency_contact_phone,
          emergency_contact_relation = EXCLUDED.emergency_contact_relation,
          preferred_locations = EXCLUDED.preferred_locations,
          preferred_garba_style = EXCLUDED.preferred_garba_style,
          avatar_url = EXCLUDED.avatar_url,
          updated_at = NOW()`,
        [
          profile.userId,
          profile.name,
          profile.email,
          profile.phone,
          profile.city || 'Ahmedabad',
          profile.age || null,
          profile.gender || null,
          profile.bio || '',
          profile.emergencyContactName || null,
          profile.emergencyContactPhone || null,
          profile.emergencyContactRelation || null,
          profile.preferredLocations || [],
          profile.preferredGarbaStyle || null,
          profile.avatarUrl || null,
        ]
      );
    } catch (e) {
      console.warn('Postgres upsertUserProfile error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('user_profiles').upsert({
        user_id: profile.userId,
        name: profile.name,
        email: profile.email,
        phone: profile.phone,
        city: profile.city || 'Ahmedabad',
        age: profile.age || null,
        gender: profile.gender || null,
        bio: profile.bio || '',
        emergency_contact_name: profile.emergencyContactName || null,
        emergency_contact_phone: profile.emergencyContactPhone || null,
        emergency_contact_relation: profile.emergencyContactRelation || null,
        preferred_locations: profile.preferredLocations || [],
        preferred_garba_style: profile.preferredGarbaStyle || null,
        avatar_url: profile.avatarUrl || null,
        updated_at: new Date().toISOString(),
      });
    } catch (e) {}
  }

  const db = readLocalDb();
  if (!db.profiles) db.profiles = [];
  const idx = db.profiles.findIndex((p) => p.userId.toLowerCase() === profile.userId.toLowerCase());
  if (idx >= 0) {
    db.profiles[idx] = { ...db.profiles[idx], ...profile };
  } else {
    db.profiles.push(profile);
  }
  writeLocalDb(db);
  return profile;
}

// ==========================================
// HOST COMPANION APPLICATIONS
// ==========================================

export async function getAllApplications(): Promise<HostApplicantRecord[]> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      const res = await pool.query('SELECT * FROM public.host_applications ORDER BY created_at DESC');
      return res.rows.map((row) => ({
        id: row.id,
        userId: row.user_id,
        name: row.name,
        age: Number(row.age) || 22,
        dateOfBirth: row.date_of_birth,
        city: row.city || 'Ahmedabad',
        area: row.area || 'Central',
        localityArea: row.locality_area || row.area,
        garbaStyle: row.garba_style || 'Traditional 2-Taali & 3-Taali',
        appliedAt: row.applied_at ? new Date(row.applied_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Recently',
        idDocument: row.id_document || 'Govt ID Proof',
        aadhaarImage: row.aadhaar_image,
        selfieImage: row.selfie_image,
        profilePhoto: row.profile_photo || row.avatar,
        avatar: row.avatar || row.profile_photo,
        registrationFeePaid: Boolean(row.registration_fee_paid),
        faceMatchScore: row.face_match_score || 'Not performed',
        status: (row.status || 'pending_review') as any,
        phone: row.phone,
        email: row.email,
        experienceYears: row.experience_years,
        bio: row.bio,
        languages: row.languages,
        hourlyRate: row.hourly_rate ? Number(row.hourly_rate) : undefined,
        phoneVerified: Boolean(row.phone_verified),
        reviewStatus: row.review_status || 'Pending Review',
      }));
    } catch (e) {
      console.warn('Postgres fetch applications error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('host_applications')
        .select('*')
        .order('created_at', { ascending: false });
      if (!error && data) {
        return data.map((row: any) => ({
          id: row.id,
          userId: row.user_id,
          name: row.name,
          age: Number(row.age) || 22,
          dateOfBirth: row.date_of_birth,
          city: row.city || 'Ahmedabad',
          area: row.area || 'Central',
          localityArea: row.locality_area || row.area,
          garbaStyle: row.garba_style || 'Traditional 2-Taali & 3-Taali',
          appliedAt: row.applied_at ? new Date(row.applied_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Recently',
          idDocument: row.id_document || 'Govt ID Proof',
          aadhaarImage: row.aadhaar_image,
          selfieImage: row.selfie_image,
          profilePhoto: row.profile_photo || row.avatar,
          avatar: row.avatar || row.profile_photo,
          registrationFeePaid: Boolean(row.registration_fee_paid),
          faceMatchScore: row.face_match_score || 'Not performed',
          status: (row.status || 'pending_review') as any,
          phone: row.phone,
          email: row.email,
          experienceYears: row.experience_years,
          bio: row.bio,
          languages: row.languages,
          hourlyRate: row.hourly_rate ? Number(row.hourly_rate) : undefined,
          phoneVerified: Boolean(row.phone_verified),
          reviewStatus: row.review_status || 'Pending Review',
        }));
      }
    } catch (e) {}
  }

  const db = readLocalDb();
  return db.applications || [];
}

export async function createApplicationRecord(app: HostApplicantRecord): Promise<HostApplicantRecord> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      await pool.query(
        `INSERT INTO public.host_applications (
          id, user_id, name, age, date_of_birth, city, area, locality_area,
          garba_style, applied_at, id_document, aadhaar_image, selfie_image,
          profile_photo, avatar, registration_fee_paid, face_match_score,
          status, phone, email, experience_years, bio, languages, hourly_rate,
          phone_verified, review_status, created_at, updated_at
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13,
          $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24,
          $25, $26, NOW(), NOW()
        )
        ON CONFLICT (id) DO UPDATE SET
          name = EXCLUDED.name,
          age = EXCLUDED.age,
          date_of_birth = EXCLUDED.date_of_birth,
          city = EXCLUDED.city,
          area = EXCLUDED.area,
          garba_style = EXCLUDED.garba_style,
          id_document = EXCLUDED.id_document,
          aadhaar_image = EXCLUDED.aadhaar_image,
          selfie_image = EXCLUDED.selfie_image,
          profile_photo = EXCLUDED.profile_photo,
          avatar = EXCLUDED.avatar,
          status = EXCLUDED.status,
          bio = EXCLUDED.bio,
          languages = EXCLUDED.languages,
          hourly_rate = EXCLUDED.hourly_rate,
          updated_at = NOW()`,
        [
          app.id,
          app.userId,
          app.name,
          app.age,
          app.dateOfBirth || null,
          app.city || 'Ahmedabad',
          app.area || 'Central',
          app.localityArea || app.area || 'Central',
          app.garbaStyle || 'Traditional 2-Taali & 3-Taali',
          app.appliedAt || new Date().toISOString(),
          app.idDocument || 'Govt ID Proof',
          app.aadhaarImage || '',
          app.selfieImage || '',
          app.profilePhoto || app.avatar || '',
          app.avatar || app.profilePhoto || '',
          app.registrationFeePaid ?? false,
          app.faceMatchScore || 'Not performed',
          app.status || 'pending_review',
          app.phone || '',
          app.email || '',
          app.experienceYears || '2',
          app.bio || '',
          app.languages || 'Gujarati, Hindi, English',
          app.hourlyRate || 1200,
          app.phoneVerified ?? false,
          app.reviewStatus || 'Pending Review',
        ]
      );
    } catch (e) {
      console.warn('Postgres createApplication error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('host_applications').upsert({
        id: app.id,
        user_id: app.userId,
        name: app.name,
        age: app.age,
        date_of_birth: app.dateOfBirth,
        city: app.city,
        area: app.area,
        locality_area: app.localityArea,
        garba_style: app.garbaStyle,
        applied_at: app.appliedAt || new Date().toISOString(),
        id_document: app.idDocument,
        aadhaar_image: app.aadhaarImage,
        selfie_image: app.selfieImage,
        profile_photo: app.profilePhoto || app.avatar,
        avatar: app.avatar || app.profilePhoto,
        registration_fee_paid: app.registrationFeePaid ?? false,
        face_match_score: app.faceMatchScore || 'Not performed',
        status: app.status || 'pending_review',
        phone: app.phone,
        email: app.email,
        experience_years: app.experienceYears,
        bio: app.bio,
        languages: app.languages,
        hourly_rate: app.hourlyRate,
        phone_verified: app.phoneVerified ?? false,
        review_status: app.reviewStatus || 'Pending Review',
        updated_at: new Date().toISOString(),
      });
    } catch (e) {}
  }

  const db = readLocalDb();
  if (!db.applications) db.applications = [];
  const idx = db.applications.findIndex((a) => a.id === app.id);
  if (idx >= 0) {
    db.applications[idx] = { ...db.applications[idx], ...app };
  } else {
    db.applications = [app, ...db.applications];
  }
  writeLocalDb(db);
  return app;
}

export async function updateApplicationRecord(
  id: string,
  updates: Partial<HostApplicantRecord>
): Promise<HostApplicantRecord | null> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      const setClauses: string[] = [];
      const values: any[] = [];
      let i = 1;

      if (updates.status !== undefined) {
        setClauses.push(`status = $${i++}`);
        values.push(updates.status);
      }
      if (updates.reviewStatus !== undefined) {
        setClauses.push(`review_status = $${i++}`);
        values.push(updates.reviewStatus);
      }
      if (updates.registrationFeePaid !== undefined) {
        setClauses.push(`registration_fee_paid = $${i++}`);
        values.push(updates.registrationFeePaid);
      }
      if (updates.phoneVerified !== undefined) {
        setClauses.push(`phone_verified = $${i++}`);
        values.push(updates.phoneVerified);
      }
      if (updates.faceMatchScore !== undefined) {
        setClauses.push(`face_match_score = $${i++}`);
        values.push(updates.faceMatchScore);
      }

      setClauses.push(`updated_at = NOW()`);

      if (setClauses.length > 0) {
        values.push(id);
        await pool.query(
          `UPDATE public.host_applications SET ${setClauses.join(', ')} WHERE id = $${i}`,
          values
        );
      }
    } catch (e) {
      console.warn('Postgres updateApplication error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('host_applications').update(updates).eq('id', id);
    } catch (e) {}
  }

  const db = readLocalDb();
  if (!db.applications) db.applications = [];
  const idx = db.applications.findIndex((a) => a.id === id);
  if (idx >= 0) {
    db.applications[idx] = { ...db.applications[idx], ...updates };
    writeLocalDb(db);
    return db.applications[idx];
  }
  return null;
}

// ==========================================
// BOOKINGS CRUD OPERATIONS
// ==========================================

export async function getAllBookings(filter?: { customerId?: string; companionId?: string }): Promise<BookingRecord[]> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      let query = 'SELECT * FROM public.bookings';
      const values: any[] = [];
      if (filter?.customerId) {
        query += ' WHERE customer_id = $1';
        values.push(filter.customerId);
      } else if (filter?.companionId) {
        query += ' WHERE companion_id = $1';
        values.push(filter.companionId);
      }
      query += ' ORDER BY created_at DESC';

      const res = await pool.query(query, values);
      return res.rows.map((row) => ({
        id: row.id,
        bookingReference: row.booking_reference,
        customerId: row.customer_id,
        customerName: row.customer_name,
        customerPhone: row.customer_phone,
        companionId: row.companion_id,
        companionName: row.companion_name,
        companionPhone: row.companion_phone,
        companionUpi: row.companion_upi,
        companionAge: row.companion_age ? Number(row.companion_age) : undefined,
        companionCity: row.companion_city,
        companionAvatar: row.companion_avatar,
        date: row.date,
        rawDate: row.raw_date,
        timeSlot: row.time_slot,
        durationPackage: row.duration_package,
        venue: row.venue,
        city: row.city,
        basePrice: Number(row.base_price),
        platformFee: Number(row.platform_fee),
        totalPrice: Number(row.total_price),
        companionEarnings: Number(row.companion_earnings),
        status: row.status,
        paymentStatus: row.payment_status,
        paymentReference: row.payment_reference,
        escrowStatus: row.escrow_status,
        completionOtp: row.completion_otp,
        otpVerified: Boolean(row.otp_verified),
        checkInAt: row.check_in_at,
        completedAt: row.completed_at,
        payoutStatus: row.payout_status,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
      }));
    } catch (e) {
      console.warn('Postgres fetch bookings error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      let query = supabase.from('bookings').select('*').order('created_at', { ascending: false });
      if (filter?.customerId) {
        query = query.eq('customer_id', filter.customerId);
      } else if (filter?.companionId) {
        query = query.eq('companion_id', filter.companionId);
      }
      const { data, error } = await query;
      if (!error && data) {
        return data.map((row: any) => ({
          id: row.id,
          bookingReference: row.booking_reference,
          customerId: row.customer_id,
          customerName: row.customer_name,
          customerPhone: row.customer_phone,
          companionId: row.companion_id,
          companionName: row.companion_name,
          companionPhone: row.companion_phone,
          companionUpi: row.companion_upi,
          companionAge: row.companion_age ? Number(row.companion_age) : undefined,
          companionCity: row.companion_city,
          companionAvatar: row.companion_avatar,
          date: row.date,
          rawDate: row.raw_date,
          timeSlot: row.time_slot,
          durationPackage: row.duration_package,
          venue: row.venue,
          city: row.city,
          basePrice: Number(row.base_price),
          platformFee: Number(row.platform_fee),
          totalPrice: Number(row.total_price),
          companionEarnings: Number(row.companion_earnings),
          status: row.status,
          paymentStatus: row.payment_status,
          paymentReference: row.payment_reference,
          escrowStatus: row.escrow_status,
          completionOtp: row.completion_otp,
          otpVerified: Boolean(row.otp_verified),
          checkInAt: row.check_in_at,
          completedAt: row.completed_at,
          payoutStatus: row.payout_status,
          createdAt: row.created_at,
          updatedAt: row.updated_at,
        }));
      }
    } catch (e) {}
  }

  const db = readLocalDb();
  let list = db.bookings || [];
  if (filter?.customerId) list = list.filter((b) => b.customerId === filter.customerId);
  if (filter?.companionId) list = list.filter((b) => b.companionId === filter.companionId);
  return list;
}

export async function createBookingRecord(b: BookingRecord): Promise<BookingRecord> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      await pool.query(
        `INSERT INTO public.bookings (
          id, booking_reference, customer_id, customer_name, customer_phone,
          companion_id, companion_name, companion_phone, companion_upi, companion_age, companion_city, companion_avatar,
          date, raw_date, time_slot, duration_package, venue, city,
          base_price, platform_fee, total_price, companion_earnings,
          status, payment_status, payment_reference, escrow_status, completion_otp, otp_verified,
          payout_status, created_at, updated_at
        ) VALUES (
          $1, $2, $3, $4, $5,
          $6, $7, $8, $9, $10, $11, $12,
          $13, $14, $15, $16, $17, $18,
          $19, $20, $21, $22,
          $23, $24, $25, $26, $27, $28,
          $29, $30, $31
        )`,
        [
          b.id,
          b.bookingReference,
          b.customerId,
          b.customerName,
          b.customerPhone || '',
          b.companionId,
          b.companionName,
          b.companionPhone || '',
          b.companionUpi || '',
          b.companionAge || 22,
          b.companionCity || 'Ahmedabad',
          b.companionAvatar || '',
          b.date,
          b.rawDate || '',
          b.timeSlot,
          b.durationPackage,
          b.venue,
          b.city || 'Ahmedabad',
          b.basePrice,
          b.platformFee,
          b.totalPrice,
          b.companionEarnings,
          b.status || 'PENDING_PAYMENT_VERIFICATION',
          b.paymentStatus || 'PENDING',
          b.paymentReference || '',
          b.escrowStatus || 'Held in Escrow',
          b.completionOtp || '',
          Boolean(b.otpVerified),
          b.payoutStatus || 'escrow_held',
          b.createdAt || new Date().toISOString(),
          new Date().toISOString(),
        ]
      );
    } catch (e) {
      console.warn('Postgres createBooking error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('bookings').upsert({
        id: b.id,
        booking_reference: b.bookingReference,
        customer_id: b.customerId,
        customer_name: b.customerName,
        customer_phone: b.customerPhone,
        companion_id: b.companionId,
        companion_name: b.companionName,
        companion_phone: b.companionPhone,
        companion_upi: b.companionUpi,
        companion_age: b.companionAge,
        companion_city: b.companionCity,
        companion_avatar: b.companionAvatar,
        date: b.date,
        raw_date: b.rawDate,
        time_slot: b.timeSlot,
        duration_package: b.durationPackage,
        venue: b.venue,
        city: b.city,
        base_price: b.basePrice,
        platform_fee: b.platformFee,
        total_price: b.totalPrice,
        companion_earnings: b.companionEarnings,
        status: b.status,
        payment_status: b.paymentStatus,
        payment_reference: b.paymentReference,
        escrow_status: b.escrowStatus,
        completion_otp: b.completionOtp,
        otp_verified: b.otpVerified,
        payout_status: b.payoutStatus,
        created_at: b.createdAt || new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
    } catch (e) {}
  }

  const db = readLocalDb();
  if (!db.bookings) db.bookings = [];
  db.bookings = [b, ...db.bookings.filter((item) => item.id !== b.id)];
  writeLocalDb(db);
  return b;
}

export async function updateBookingRecord(id: string, updates: Partial<BookingRecord>): Promise<BookingRecord | null> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      const setClauses: string[] = [];
      const values: any[] = [];
      let i = 1;

      if (updates.status !== undefined) {
        setClauses.push(`status = $${i++}`);
        values.push(updates.status);
      }
      if (updates.paymentStatus !== undefined) {
        setClauses.push(`payment_status = $${i++}`);
        values.push(updates.paymentStatus);
      }
      if (updates.paymentReference !== undefined) {
        setClauses.push(`payment_reference = $${i++}`);
        values.push(updates.paymentReference);
      }
      if (updates.completionOtp !== undefined) {
        setClauses.push(`completion_otp = $${i++}`);
        values.push(updates.completionOtp);
      }
      if (updates.otpVerified !== undefined) {
        setClauses.push(`otp_verified = $${i++}`);
        values.push(updates.otpVerified);
      }
      if (updates.payoutStatus !== undefined) {
        setClauses.push(`payout_status = $${i++}`);
        values.push(updates.payoutStatus);
      }
      if (updates.completedAt !== undefined) {
        setClauses.push(`completed_at = $${i++}`);
        values.push(updates.completedAt);
      }

      setClauses.push(`updated_at = NOW()`);
      if (setClauses.length > 0) {
        values.push(id);
        await pool.query(`UPDATE public.bookings SET ${setClauses.join(', ')} WHERE id = $${i}`, values);
      }
    } catch (e) {
      console.warn('Postgres updateBooking error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('bookings').update(updates).eq('id', id);
    } catch (e) {}
  }

  const db = readLocalDb();
  if (!db.bookings) db.bookings = [];
  const idx = db.bookings.findIndex((item) => item.id === id);
  if (idx >= 0) {
    db.bookings[idx] = { ...db.bookings[idx], ...updates };
    writeLocalDb(db);
    return db.bookings[idx];
  }
  return null;
}

// ==========================================
// PAYOUTS CRUD OPERATIONS
// ==========================================

export async function getAllPayouts(): Promise<PayoutRecord[]> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      const res = await pool.query('SELECT * FROM public.payouts ORDER BY created_at DESC');
      return res.rows.map((row) => ({
        id: row.id,
        bookingId: row.booking_id,
        companionId: row.companion_id,
        companionName: row.companion_name,
        companionUpi: row.companion_upi,
        amount: Number(row.amount),
        platformFee: Number(row.platform_fee),
        grossAmount: Number(row.gross_amount),
        status: row.status,
        transactionReference: row.transaction_reference,
        approvedAt: row.approved_at,
        approvedBy: row.approved_by,
        paidAt: row.paid_at,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
      }));
    } catch (e) {
      console.warn('Postgres fetch payouts error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      const { data, error } = await supabase.from('payouts').select('*').order('created_at', { ascending: false });
      if (!error && data) {
        return data.map((row: any) => ({
          id: row.id,
          bookingId: row.booking_id,
          companionId: row.companion_id,
          companionName: row.companion_name,
          companionUpi: row.companion_upi,
          amount: Number(row.amount),
          platformFee: Number(row.platform_fee),
          grossAmount: Number(row.gross_amount),
          status: row.status,
          transactionReference: row.transaction_reference,
          approvedAt: row.approved_at,
          approvedBy: row.approved_by,
          paidAt: row.paid_at,
          createdAt: row.created_at,
          updatedAt: row.updated_at,
        }));
      }
    } catch (e) {}
  }

  const db = readLocalDb();
  return db.payouts || [];
}

export async function createPayoutRecord(p: PayoutRecord): Promise<PayoutRecord> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      await pool.query(
        `INSERT INTO public.payouts (
          id, booking_id, companion_id, companion_name, companion_upi,
          amount, platform_fee, gross_amount, status, transaction_reference,
          created_at, updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`,
        [
          p.id,
          p.bookingId,
          p.companionId,
          p.companionName,
          p.companionUpi,
          p.amount,
          p.platformFee,
          p.grossAmount,
          p.status || 'PENDING_ADMIN_APPROVAL',
          p.transactionReference || '',
          p.createdAt || new Date().toISOString(),
          new Date().toISOString(),
        ]
      );
    } catch (e) {
      console.warn('Postgres createPayout error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('payouts').upsert({
        id: p.id,
        booking_id: p.bookingId,
        companion_id: p.companionId,
        companion_name: p.companionName,
        companion_upi: p.companionUpi,
        amount: p.amount,
        platform_fee: p.platformFee,
        gross_amount: p.grossAmount,
        status: p.status,
        transaction_reference: p.transactionReference,
        created_at: p.createdAt || new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
    } catch (e) {}
  }

  const db = readLocalDb();
  if (!db.payouts) db.payouts = [];
  db.payouts = [p, ...db.payouts.filter((item) => item.id !== p.id)];
  writeLocalDb(db);
  return p;
}

export async function updatePayoutRecord(id: string, updates: Partial<PayoutRecord>): Promise<PayoutRecord | null> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      const setClauses: string[] = [];
      const values: any[] = [];
      let i = 1;

      if (updates.status !== undefined) {
        setClauses.push(`status = $${i++}`);
        values.push(updates.status);
      }
      if (updates.transactionReference !== undefined) {
        setClauses.push(`transaction_reference = $${i++}`);
        values.push(updates.transactionReference);
      }
      if (updates.approvedAt !== undefined) {
        setClauses.push(`approved_at = $${i++}`);
        values.push(updates.approvedAt);
      }
      if (updates.approvedBy !== undefined) {
        setClauses.push(`approved_by = $${i++}`);
        values.push(updates.approvedBy);
      }
      if (updates.paidAt !== undefined) {
        setClauses.push(`paid_at = $${i++}`);
        values.push(updates.paidAt);
      }

      setClauses.push(`updated_at = NOW()`);
      if (setClauses.length > 0) {
        values.push(id);
        await pool.query(`UPDATE public.payouts SET ${setClauses.join(', ')} WHERE id = $${i}`, values);
      }
    } catch (e) {
      console.warn('Postgres updatePayout error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('payouts').update(updates).eq('id', id);
    } catch (e) {}
  }

  const db = readLocalDb();
  if (!db.payouts) db.payouts = [];
  const idx = db.payouts.findIndex((item) => item.id === id);
  if (idx >= 0) {
    db.payouts[idx] = { ...db.payouts[idx], ...updates };
    writeLocalDb(db);
    return db.payouts[idx];
  }
  return null;
}

// ==========================================
// COMPLAINTS CRUD OPERATIONS
// ==========================================

export async function getAllComplaints(): Promise<ComplaintRecord[]> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      const res = await pool.query('SELECT * FROM public.complaints ORDER BY created_at DESC');
      return res.rows.map((row) => ({
        id: row.id,
        bookingId: row.booking_id,
        reporterType: row.reporter_type,
        reporterName: row.reporter_name,
        reporterPhone: row.reporter_phone,
        targetName: row.target_name,
        category: row.category,
        severity: row.severity,
        status: row.status,
        subject: row.subject,
        description: row.description,
        assignedAdmin: row.assigned_admin,
        resolutionNotes: row.resolution_notes,
        resolvedAt: row.resolved_at,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
      }));
    } catch (e) {
      console.warn('Postgres fetch complaints error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      const { data, error } = await supabase.from('complaints').select('*').order('created_at', { ascending: false });
      if (!error && data) {
        return data.map((row: any) => ({
          id: row.id,
          bookingId: row.booking_id,
          reporterType: row.reporter_type,
          reporterName: row.reporter_name,
          reporterPhone: row.reporter_phone,
          targetName: row.target_name,
          category: row.category,
          severity: row.severity,
          status: row.status,
          subject: row.subject,
          description: row.description,
          assignedAdmin: row.assigned_admin,
          resolutionNotes: row.resolution_notes,
          resolvedAt: row.resolved_at,
          createdAt: row.created_at,
          updatedAt: row.updated_at,
        }));
      }
    } catch (e) {}
  }

  const db = readLocalDb();
  return db.complaints || [];
}

export async function createComplaintRecord(c: ComplaintRecord): Promise<ComplaintRecord> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      await pool.query(
        `INSERT INTO public.complaints (
          id, booking_id, reporter_type, reporter_name, reporter_phone,
          target_name, category, severity, status, subject, description,
          created_at, updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
        [
          c.id,
          c.bookingId || '',
          c.reporterType,
          c.reporterName,
          c.reporterPhone || '',
          c.targetName,
          c.category,
          c.severity || 'medium',
          c.status || 'open',
          c.subject,
          c.description,
          c.createdAt || new Date().toISOString(),
          new Date().toISOString(),
        ]
      );
    } catch (e) {
      console.warn('Postgres createComplaint error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('complaints').upsert({
        id: c.id,
        booking_id: c.bookingId,
        reporter_type: c.reporterType,
        reporter_name: c.reporterName,
        reporter_phone: c.reporterPhone,
        target_name: c.targetName,
        category: c.category,
        severity: c.severity,
        status: c.status,
        subject: c.subject,
        description: c.description,
        created_at: c.createdAt || new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
    } catch (e) {}
  }

  const db = readLocalDb();
  if (!db.complaints) db.complaints = [];
  db.complaints = [c, ...db.complaints.filter((item) => item.id !== c.id)];
  writeLocalDb(db);
  return c;
}

export async function updateComplaintRecord(id: string, updates: Partial<ComplaintRecord>): Promise<ComplaintRecord | null> {
  await initSchemaIfNeeded();
  const pool = getPostgresPool();
  if (pool) {
    try {
      const setClauses: string[] = [];
      const values: any[] = [];
      let i = 1;

      if (updates.status !== undefined) {
        setClauses.push(`status = $${i++}`);
        values.push(updates.status);
      }
      if (updates.assignedAdmin !== undefined) {
        setClauses.push(`assigned_admin = $${i++}`);
        values.push(updates.assignedAdmin);
      }
      if (updates.resolutionNotes !== undefined) {
        setClauses.push(`resolution_notes = $${i++}`);
        values.push(updates.resolutionNotes);
      }
      if (updates.resolvedAt !== undefined) {
        setClauses.push(`resolved_at = $${i++}`);
        values.push(updates.resolvedAt);
      }

      setClauses.push(`updated_at = NOW()`);
      if (setClauses.length > 0) {
        values.push(id);
        await pool.query(`UPDATE public.complaints SET ${setClauses.join(', ')} WHERE id = $${i}`, values);
      }
    } catch (e) {
      console.warn('Postgres updateComplaint error:', e);
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('complaints').update(updates).eq('id', id);
    } catch (e) {}
  }

  const db = readLocalDb();
  if (!db.complaints) db.complaints = [];
  const idx = db.complaints.findIndex((item) => item.id === id);
  if (idx >= 0) {
    db.complaints[idx] = { ...db.complaints[idx], ...updates };
    writeLocalDb(db);
    return db.complaints[idx];
  }
  return null;
}

// ==========================================
// ACTIVE COMPANIONS FOR PUBLIC MARKETPLACE
// ==========================================
// Rule 33: Only show companions where:
// role = COMPANION, applicationStatus = APPROVED,
// verificationStatus = VERIFIED, accountStatus = ACTIVE
export async function getActiveCompanions(): Promise<any[]> {
  const users = await getAllUsers();
  const applications = await getAllApplications();

  const activeCompanions: any[] = [];

  for (const user of users) {
    const roleLower = (user.role || '').toLowerCase();
    const isCompanion = roleLower === 'companion';
    const isActive = user.accountStatus === 'active';

    if (!isCompanion || !isActive) continue;

    const app = applications.find((a) => a.userId.toLowerCase() === user.userId.toLowerCase());
    const isAppApproved = app && app.status === 'approved';

    // Must be approved companion
    if (isAppApproved) {
      const hourly = Number(user.hourlyRate || app?.hourlyRate || 1200);
      activeCompanions.push({
        id: user.userId,
        name: user.name,
        age: user.age || app?.age || 22,
        city: user.city || 'Ahmedabad',
        area: app?.area || user.availableCities || 'Central Ahmedabad',
        rating: 4.9,
        reviewsCount: 12,
        avatarUrl: user.profilePhoto || app?.profilePhoto || user.selfieImage || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
        phone: user.phone || user.mobile,
        bioSnippet: user.bio || app?.bio || 'Passionate Garba dancer and certified cultural companion.',
        experiences: [user.garbaStyle || app?.garbaStyle || 'Traditional Garba', 'Cultural Guide', 'Folk Dance'],
        durations: [2, 4],
        price2h: hourly,
        price4h: Math.round(hourly * 1.8),
        availableTonight: true,
        availableDates: ['2026-10-10', '2026-10-11', '2026-10-12', '2026-10-13', '2026-10-14', '2026-10-15', '2026-10-16', '2026-10-17', '2026-10-18'],
        isVerified: true,
        registrationFeePaid: true,
        hasCompletedProfile: true,
        status: 'active',
      });
    }
  }

  return activeCompanions;
}

