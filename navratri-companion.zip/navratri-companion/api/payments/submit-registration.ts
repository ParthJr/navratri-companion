import { parseRequestBody } from '../auth/_authUtils.ts';
import { createPayment, getUserByIdentifier, updateUser, PaymentRecord } from '../_db.ts';

export default async function handler(req: any, res: any) {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');

  if (req.method !== 'POST') {
    res.statusCode = 405;
    return res.end(JSON.stringify({ success: false, errorMessage: 'Method Not Allowed' }));
  }

  try {
    const body = await parseRequestBody(req);
    const userId = (body.userId || '').toString().trim();
    const paymentReference = (body.paymentReference || '').toString().trim();
    const amount = Number(body.amount) || 499;
    const paymentMethod = (body.paymentMethod || 'UPI').toString().trim();

    if (!userId || !paymentReference) {
      res.statusCode = 400;
      return res.end(
        JSON.stringify({
          success: false,
          errorMessage: 'User ID and Payment Reference are required.',
        })
      );
    }

    const existingUser = await getUserByIdentifier(userId);
    if (!existingUser) {
      res.statusCode = 404;
      return res.end(
        JSON.stringify({
          success: false,
          errorMessage: `User record with ID "${userId}" was not found.`,
        })
      );
    }

    const now = new Date().toISOString();
    const paymentRecord: PaymentRecord = {
      id: `regpay_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      userId: existingUser.userId,
      amount: amount,
      paymentMethod: paymentMethod,
      paymentReference: paymentReference,
      paymentStatus: 'PENDING',
      submittedAt: now,
      approvedAt: null,
      approvedBy: null,
      rejectedAt: null,
      rejectionReason: null,
      createdAt: now,
      updatedAt: now,
      notes: 'Registration fee awaiting platform admin confirmation',
    };

    const savedPayment = await createPayment(paymentRecord);

    const updatedUser = await updateUser(existingUser.userId, {
      paymentStatus: 'pending',
      accountStatus: 'pending_approval',
      feePaid: false,
      loginEnabled: false,
      paymentReference: paymentReference,
      paymentSubmittedAt: now,
    });

    res.statusCode = 200;
    return res.end(
      JSON.stringify({
        success: true,
        message: 'Payment reference submitted successfully. Awaiting Admin verification.',
        payment: savedPayment,
        user: updatedUser,
      })
    );
  } catch (err: any) {
    res.statusCode = 500;
    return res.end(
      JSON.stringify({
        success: false,
        errorMessage: 'Payment submission failed. Please try again.',
      })
    );
  }
}
