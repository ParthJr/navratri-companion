import { getAllPayments, getAllUsers } from '../_db.ts';

export default async function handler(req: any, res: any) {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');

  if (req.method !== 'GET') {
    res.statusCode = 405;
    return res.end(JSON.stringify({ success: false, errorMessage: 'Method Not Allowed' }));
  }

  try {
    const users = await getAllUsers();
    const payments = await getAllPayments();

    // Only include users who have actually submitted payment (pending_approval, approved, rejected, or have a submitted payment record)
    // Users in 'pending_payment' who have NOT submitted their UPI ref yet belong in Users tab, NOT in the Payment Approvals queue!
    const approvalRequests: any[] = [];

    users.forEach((u) => {
      // Find latest payment for this user
      const userPayments = payments.filter(
        (p) => p.userId.toLowerCase() === u.userId.toLowerCase()
      );
      const latestPayment = userPayments[0] || null;

      const pStatus = (latestPayment?.paymentStatus || u.paymentStatus || 'pending').toLowerCase();
      const aStatus = (u.accountStatus || 'pending_payment').toLowerCase();

      // Check if user has actually submitted a payment reference
      const hasSubmittedPayment =
        aStatus === 'pending_approval' ||
        Boolean(u.paymentSubmittedAt) ||
        Boolean(latestPayment) ||
        pStatus === 'approved' ||
        pStatus === 'rejected';

      if (!hasSubmittedPayment) {
        return; // Skip users who haven't submitted payment yet
      }

      const isApproved = (u.feePaid || pStatus === 'approved') && aStatus === 'active';
      const isRejected = pStatus === 'rejected' || aStatus === 'payment_rejected';

      let displayStatus: 'Pending Verification' | 'Approved' | 'Rejected' = 'Pending Verification';
      if (isApproved) {
        displayStatus = 'Approved';
      } else if (isRejected) {
        displayStatus = 'Rejected';
      }

      approvalRequests.push({
        id: u.id,
        userId: u.userId,
        name: u.name,
        email: u.email,
        phone: u.phone || u.mobile || '',
        role: u.role || 'customer',
        city: u.city || 'Ahmedabad',
        amount: latestPayment?.amount || 499,
        paymentReference: u.paymentReference || latestPayment?.paymentReference || (isApproved ? 'Approved' : 'Submitted (Pending Ref)'),
        submittedAt: u.paymentSubmittedAt || latestPayment?.submittedAt || latestPayment?.createdAt || u.createdAt,
        approvedAt: u.approvedAt || latestPayment?.approvedAt,
        approvedBy: u.approvedBy || latestPayment?.approvedBy,
        rejectedAt: u.rejectedAt || latestPayment?.rejectedAt,
        rejectionReason: u.rejectionReason || latestPayment?.rejectionReason || '',
        status: displayStatus,
        paymentStatus: pStatus.toUpperCase(),
        accountStatus: aStatus,
        feePaid: Boolean(u.feePaid),
        loginEnabled: isApproved,
        profilePhoto: u.profilePhoto || '',
        aadhaarImage: u.aadhaarImage,
        selfieImage: u.selfieImage,
        policyConsent: u.policyConsent,
        registrationDate: u.createdAt,
      });
    });

    const pendingCount = approvalRequests.filter((r) => r.status === 'Pending Verification').length;
    const approvedCount = approvalRequests.filter((r) => r.status === 'Approved').length;
    const rejectedCount = approvalRequests.filter((r) => r.status === 'Rejected').length;

    res.statusCode = 200;
    return res.end(
      JSON.stringify({
        success: true,
        requests: approvalRequests,
        pendingCount,
        approvedCount,
        rejectedCount,
        total: approvalRequests.length,
      })
    );
  } catch (err: any) {
    res.statusCode = 500;
    return res.end(
      JSON.stringify({
        success: false,
        errorMessage: 'Failed to fetch payment approvals from production database.',
      })
    );
  }
}
