import { parseRequestBody } from '../auth/_authUtils.ts';
import { getUserByIdentifier, updatePayment, updateUser } from '../_db.ts';

export default async function handler(req: any, res: any) {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');

  if (req.method !== 'POST') {
    res.statusCode = 405;
    return res.end(JSON.stringify({ success: false, errorMessage: 'Method Not Allowed' }));
  }

  try {
    const body = await parseRequestBody(req);
    const userId = (body.userId || '').toString().trim();
    const reason = (body.reason || 'Invalid transaction reference / payment not verified in bank statement').toString().trim();
    const rejectedBy = (body.rejectedBy || 'parthjunior23 (Master Admin)').toString().trim();

    if (!userId) {
      res.statusCode = 400;
      return res.end(
        JSON.stringify({
          success: false,
          errorMessage: 'User ID is required to reject payment.',
        })
      );
    }

    const user = await getUserByIdentifier(userId);
    if (!user) {
      res.statusCode = 404;
      return res.end(
        JSON.stringify({
          success: false,
          errorMessage: `User @${userId} not found in central database.`,
        })
      );
    }

    const now = new Date().toISOString();

    // 1. Update Payment Record
    const updatedPayment = await updatePayment(user.userId, {
      paymentStatus: 'REJECTED',
      rejectedAt: now,
      rejectionReason: reason,
      approvedAt: null,
      approvedBy: rejectedBy,
      notes: `Rejected by ${rejectedBy}: ${reason}`,
    });

    // 2. Update User Record
    const updatedUser = await updateUser(user.userId, {
      accountStatus: 'payment_rejected',
      paymentStatus: 'rejected',
      feePaid: false,
      loginEnabled: false,
      rejectionReason: reason,
    });

    res.statusCode = 200;
    return res.end(
      JSON.stringify({
        success: true,
        message: `Payment rejected for @${user.userId}`,
        user: updatedUser,
        payment: updatedPayment,
      })
    );
  } catch (err: any) {
    res.statusCode = 500;
    return res.end(
      JSON.stringify({
        success: false,
        errorMessage: 'Failed to reject payment in database.',
      })
    );
  }
}
