import { parseRequestBody } from '../auth/_authUtils.ts';
import { updateApplicationRecord, getAllApplications } from '../_db.ts';

export default async function handler(req: any, res: any) {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');

  if (req.method !== 'POST') {
    res.statusCode = 405;
    return res.end(JSON.stringify({ success: false, errorMessage: 'Method Not Allowed' }));
  }

  try {
    const body = await parseRequestBody(req);
    const applicationId = (body.applicationId || body.id || '').toString().trim();

    if (!applicationId) {
      res.statusCode = 400;
      return res.end(JSON.stringify({ success: false, errorMessage: 'Application ID is required.' }));
    }

    const updated = await updateApplicationRecord(applicationId, {
      status: 'approved',
      reviewStatus: 'Approved',
      phoneVerified: true,
      registrationFeePaid: true,
    });

    if (!updated) {
      res.statusCode = 404;
      return res.end(JSON.stringify({ success: false, errorMessage: 'Application record not found.' }));
    }

    res.statusCode = 200;
    return res.end(
      JSON.stringify({
        success: true,
        message: `Application ${applicationId} approved successfully. Companion is now verified.`,
        application: updated,
      })
    );
  } catch (err: any) {
    res.statusCode = 500;
    return res.end(
      JSON.stringify({
        success: false,
        errorMessage: 'Failed to approve application.',
      })
    );
  }
}
