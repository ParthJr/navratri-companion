import { getPostgresPool, getSupabaseClient } from './_db.ts';

export default async function handler(req: any, res: any) {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');

  let dbStatus = 'disconnected';

  try {
    const pool = getPostgresPool();
    if (pool) {
      const dbRes = await pool.query('SELECT 1 as test');
      if (dbRes && dbRes.rows && dbRes.rows.length > 0) {
        dbStatus = 'connected';
      }
    } else {
      const supabase = getSupabaseClient();
      if (supabase) {
        const { error } = await supabase.from('users').select('count', { count: 'exact', head: true });
        if (!error) {
          dbStatus = 'connected';
        } else {
          dbStatus = 'configured';
        }
      } else {
        dbStatus = 'connected'; // in-memory local state ready
      }
    }
  } catch (err: any) {
    dbStatus = 'error';
  }

  res.statusCode = 200;
  return res.end(
    JSON.stringify({
      ok: true,
      database: dbStatus,
      timestamp: new Date().toISOString(),
    })
  );
}
